import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";
import {
  users,
  workspaces,
  locations,
  clients,
  equipmentTypes,
  equipmentItems,
  tariffs,
  calendar,
  orders,
  orderItems,
  orderBundleRecords,
  orderBundleAssignments,
  payments,
  discounts,
  bundleDefinitions,
  bundleComponents,
  clientTagDefinitions,
  workspaceSettings,
  type InsertUser,
  type InsertWorkspace,
  type InsertLocation,
  type InsertClient,
  type InsertEquipmentType,
  type InsertEquipmentItem,
  type InsertTariff,
  type InsertCalendar,
  type InsertOrder,
  type InsertOrderItem,
  type InsertOrderBundleRecord,
  type InsertOrderBundleAssignment,
  type InsertPayment,
  type InsertDiscount,
  type InsertBundleDefinition,
  type InsertBundleComponent,
  type User,
  type Workspace,
  type Location,
  type Client,
  type EquipmentType,
  type EquipmentItem,
  type Tariff,
  type Calendar,
  type Order,
  type OrderItem,
  type OrderBundleRecord,
  type OrderBundleAssignment,
  type Payment,
  type Discount,
  type BundleDefinition,
  type BundleComponent,
  type InsertClientTagDefinition,
  type ClientTagDefinition,
  type InsertWorkspaceSettings,
  type WorkspaceSettings,
} from "@shared/schema";

export interface IStorage {
  // Users
  insertUser(user: InsertUser): Promise<User>;
  getUserById(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  
  // Workspaces
  insertWorkspace(workspace: InsertWorkspace): Promise<Workspace>;
  getWorkspaceById(id: string): Promise<Workspace | undefined>;
  
  // Locations
  insertLocation(location: InsertLocation): Promise<Location>;
  getLocationsByWorkspace(workspaceId: string): Promise<Location[]>;
  
  // Clients
  insertClient(client: InsertClient): Promise<Client>;
  getClientsByWorkspace(workspaceId: string): Promise<Client[]>;
  getClientById(id: string): Promise<Client | undefined>;
  updateClient(id: string, data: Partial<InsertClient>): Promise<Client>;
  deleteClient(id: string): Promise<void>;
  
  // Equipment Types
  insertEquipmentType(type: InsertEquipmentType): Promise<EquipmentType>;
  getEquipmentTypesByWorkspace(workspaceId: string): Promise<EquipmentType[]>;
  
  // Equipment Items
  insertEquipmentItem(item: InsertEquipmentItem): Promise<EquipmentItem>;
  getEquipmentItemsByWorkspace(workspaceId: string): Promise<EquipmentItem[]>;
  getEquipmentItemsByLocation(locationId: string): Promise<EquipmentItem[]>;
  getEquipmentItemByItemNumber(workspaceId: string, itemNumber: string): Promise<EquipmentItem[]>;
  updateEquipmentItemStatus(id: string, status: string): Promise<void>;
  updateEquipmentItem(id: string, item: Partial<InsertEquipmentItem>): Promise<EquipmentItem>;
  deleteEquipmentItem(id: string): Promise<void>;
  
  // Tariffs
  insertTariff(tariff: InsertTariff): Promise<Tariff>;
  getTariffsByWorkspace(workspaceId: string): Promise<Tariff[]>;
  updateTariff(id: string, tariff: Partial<InsertTariff>): Promise<Tariff>;
  
  // Calendar
  insertCalendarDay(day: InsertCalendar): Promise<Calendar>;
  getCalendarByWorkspace(workspaceId: string): Promise<Calendar[]>;
  getCalendarDayById(id: string): Promise<Calendar | undefined>;
  updateCalendarDay(id: string, day: Partial<InsertCalendar>): Promise<Calendar>;
  deleteCalendarDay(id: string): Promise<void>;
  
  // Orders
  insertOrder(order: InsertOrder): Promise<Order>;
  getOrdersByWorkspace(workspaceId: string): Promise<Order[]>;
  getOrderById(id: string): Promise<Order | undefined>;
  updateOrder(id: string, order: Partial<InsertOrder>): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<void>;
  updateOrderTotals(id: string, subtotal: string, total: string): Promise<void>;
  
  // Order Items
  insertOrderItem(item: InsertOrderItem): Promise<OrderItem>;
  getOrderItemsByOrder(orderId: string): Promise<OrderItem[]>;
  deleteOrderItemsByOrder(orderId: string): Promise<void>;
  
  // Payments
  insertPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByOrder(orderId: string): Promise<Payment[]>;
  
  // Discounts
  insertDiscount(discount: InsertDiscount): Promise<Discount>;
  getDiscountsByWorkspace(workspaceId: string): Promise<Discount[]>;
  getDiscountByCode(workspaceId: string, code: string): Promise<Discount | undefined>;
  
  // Bundle Definitions
  insertBundleDefinition(bundle: InsertBundleDefinition): Promise<BundleDefinition>;
  getBundleDefinitionsByWorkspace(workspaceId: string): Promise<BundleDefinition[]>;
  getBundleDefinitionById(id: string): Promise<BundleDefinition | undefined>;
  updateBundleDefinition(id: string, bundle: Partial<InsertBundleDefinition>): Promise<BundleDefinition>;
  deleteBundleDefinition(id: string): Promise<void>;
  
  // Bundle Components
  insertBundleComponent(component: InsertBundleComponent): Promise<BundleComponent>;
  getBundleComponentsByBundle(bundleId: string): Promise<BundleComponent[]>;
  deleteBundleComponentsByBundle(bundleId: string): Promise<void>;
  deleteBundleComponent(id: string): Promise<void>;
  
  // Order Bundle Records
  insertOrderBundleRecord(record: InsertOrderBundleRecord): Promise<OrderBundleRecord>;
  getOrderBundleRecordsByOrder(orderId: string): Promise<OrderBundleRecord[]>;
  getOrderBundleRecordById(id: string): Promise<OrderBundleRecord | undefined>;
  
  // Order Bundle Assignments
  insertOrderBundleAssignment(assignment: InsertOrderBundleAssignment): Promise<OrderBundleAssignment>;
  getOrderBundleAssignmentsByRecord(orderBundleId: string): Promise<OrderBundleAssignment[]>;
  
  // Client Tag Definitions
  insertClientTagDefinition(tag: InsertClientTagDefinition): Promise<ClientTagDefinition>;
  getClientTagDefinitionsByWorkspace(workspaceId: string): Promise<ClientTagDefinition[]>;
  getClientTagDefinitionById(id: string): Promise<ClientTagDefinition | undefined>;
  updateClientTagDefinition(id: string, tag: Partial<InsertClientTagDefinition>): Promise<ClientTagDefinition>;
  deleteClientTagDefinition(id: string): Promise<void>;
  
  // Workspace Settings
  getWorkspaceSettings(workspaceId: string): Promise<WorkspaceSettings | undefined>;
  upsertWorkspaceSettings(settings: InsertWorkspaceSettings): Promise<WorkspaceSettings>;
  updateWorkspaceSettings(workspaceId: string, settings: Partial<InsertWorkspaceSettings>): Promise<WorkspaceSettings>;
}

class DatabaseStorage implements IStorage {
  // Users
  async insertUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getUserById(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  // Workspaces
  async insertWorkspace(workspace: InsertWorkspace): Promise<Workspace> {
    const [newWorkspace] = await db.insert(workspaces).values(workspace).returning();
    return newWorkspace;
  }

  async getWorkspaceById(id: string): Promise<Workspace | undefined> {
    const [workspace] = await db.select().from(workspaces).where(eq(workspaces.id, id));
    return workspace;
  }

  // Locations
  async insertLocation(location: InsertLocation): Promise<Location> {
    const [newLocation] = await db.insert(locations).values(location).returning();
    return newLocation;
  }

  async getLocationsByWorkspace(workspaceId: string): Promise<Location[]> {
    return await db.select().from(locations).where(eq(locations.workspaceId, workspaceId));
  }

  // Clients
  async insertClient(client: InsertClient): Promise<Client> {
    const [newClient] = await db.insert(clients).values(client).returning();
    return newClient;
  }

  async getClientsByWorkspace(workspaceId: string): Promise<Client[]> {
    return await db.select().from(clients).where(eq(clients.workspaceId, workspaceId)).orderBy(desc(clients.createdAt));
  }

  async getClientById(id: string): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async updateClient(id: string, data: Partial<InsertClient>): Promise<Client> {
    const [updated] = await db.update(clients).set(data).where(eq(clients.id, id)).returning();
    return updated;
  }

  async deleteClient(id: string): Promise<void> {
    await db.delete(clients).where(eq(clients.id, id));
  }

  // Equipment Types
  async insertEquipmentType(type: InsertEquipmentType): Promise<EquipmentType> {
    const [newType] = await db.insert(equipmentTypes).values(type).returning();
    return newType;
  }

  async getEquipmentTypesByWorkspace(workspaceId: string): Promise<EquipmentType[]> {
    return await db.select().from(equipmentTypes).where(eq(equipmentTypes.workspaceId, workspaceId));
  }

  // Equipment Items
  async insertEquipmentItem(item: InsertEquipmentItem): Promise<EquipmentItem> {
    const [newItem] = await db.insert(equipmentItems).values(item).returning();
    return newItem;
  }

  async getEquipmentItemsByWorkspace(workspaceId: string): Promise<EquipmentItem[]> {
    return await db.select().from(equipmentItems).where(eq(equipmentItems.workspaceId, workspaceId));
  }

  async getEquipmentItemsByLocation(locationId: string): Promise<EquipmentItem[]> {
    return await db.select().from(equipmentItems).where(eq(equipmentItems.locationId, locationId));
  }

  async getEquipmentItemByItemNumber(workspaceId: string, itemNumber: string): Promise<EquipmentItem[]> {
    return await db.select().from(equipmentItems).where(
      and(
        eq(equipmentItems.workspaceId, workspaceId),
        eq(equipmentItems.itemNumber, itemNumber)
      )
    );
  }

  async updateEquipmentItemStatus(id: string, status: string): Promise<void> {
    await db.update(equipmentItems).set({ status: status as any }).where(eq(equipmentItems.id, id));
  }

  async updateEquipmentItem(id: string, item: Partial<InsertEquipmentItem>): Promise<EquipmentItem> {
    const [updated] = await db.update(equipmentItems)
      .set(item)
      .where(eq(equipmentItems.id, id))
      .returning();
    return updated;
  }

  async deleteEquipmentItem(id: string): Promise<void> {
    await db.delete(equipmentItems).where(eq(equipmentItems.id, id));
  }

  // Tariffs
  async insertTariff(tariff: InsertTariff): Promise<Tariff> {
    const [newTariff] = await db.insert(tariffs).values(tariff).returning();
    return newTariff;
  }

  async getTariffsByWorkspace(workspaceId: string): Promise<Tariff[]> {
    return await db.select().from(tariffs).where(eq(tariffs.workspaceId, workspaceId));
  }

  async updateTariff(id: string, tariff: Partial<InsertTariff>): Promise<Tariff> {
    const [updated] = await db.update(tariffs).set(tariff).where(eq(tariffs.id, id)).returning();
    return updated;
  }

  // Calendar
  async insertCalendarDay(day: InsertCalendar): Promise<Calendar> {
    const [newDay] = await db.insert(calendar).values(day).returning();
    return newDay;
  }

  async getCalendarByWorkspace(workspaceId: string): Promise<Calendar[]> {
    return await db.select().from(calendar).where(eq(calendar.workspaceId, workspaceId));
  }

  async getCalendarDayById(id: string): Promise<Calendar | undefined> {
    const [day] = await db.select().from(calendar).where(eq(calendar.id, id));
    return day;
  }

  async updateCalendarDay(id: string, day: Partial<InsertCalendar>): Promise<Calendar> {
    const [updated] = await db
      .update(calendar)
      .set(day)
      .where(eq(calendar.id, id))
      .returning();
    if (!updated) {
      throw new Error("Calendar day not found");
    }
    return updated;
  }

  async deleteCalendarDay(id: string): Promise<void> {
    const result = await db.delete(calendar).where(eq(calendar.id, id)).returning();
    if (result.length === 0) {
      throw new Error("Calendar day not found");
    }
  }

  // Orders
  async insertOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async getOrdersByWorkspace(workspaceId: string): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.workspaceId, workspaceId)).orderBy(desc(orders.createdAt));
  }

  async getOrderById(id: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async updateOrder(id: string, orderData: Partial<InsertOrder>): Promise<Order> {
    const [updated] = await db.update(orders)
      .set({ ...orderData, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return updated;
  }

  async updateOrderStatus(id: string, status: string): Promise<void> {
    await db.update(orders).set({ status: status as any, updatedAt: new Date() }).where(eq(orders.id, id));
  }

  async updateOrderTotals(id: string, subtotal: string, total: string): Promise<void> {
    await db.update(orders).set({ subtotal, total, updatedAt: new Date() }).where(eq(orders.id, id));
  }

  // Order Items
  async insertOrderItem(item: InsertOrderItem): Promise<OrderItem> {
    const [newItem] = await db.insert(orderItems).values(item).returning();
    return newItem;
  }

  async getOrderItemsByOrder(orderId: string): Promise<OrderItem[]> {
    return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async deleteOrderItemsByOrder(orderId: string): Promise<void> {
    await db.delete(orderItems).where(eq(orderItems.orderId, orderId));
  }

  // Payments
  async insertPayment(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  async getPaymentsByOrder(orderId: string): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.orderId, orderId));
  }

  // Discounts
  async insertDiscount(discount: InsertDiscount): Promise<Discount> {
    const [newDiscount] = await db.insert(discounts).values(discount).returning();
    return newDiscount;
  }

  async getDiscountsByWorkspace(workspaceId: string): Promise<Discount[]> {
    return await db.select().from(discounts).where(eq(discounts.workspaceId, workspaceId));
  }

  async getDiscountByCode(workspaceId: string, code: string): Promise<Discount | undefined> {
    const [discount] = await db
      .select()
      .from(discounts)
      .where(and(eq(discounts.workspaceId, workspaceId), eq(discounts.code, code)));
    return discount;
  }

  // Bundle Definitions
  async insertBundleDefinition(bundle: InsertBundleDefinition): Promise<BundleDefinition> {
    const [newBundle] = await db.insert(bundleDefinitions).values(bundle).returning();
    return newBundle;
  }

  async getBundleDefinitionsByWorkspace(workspaceId: string): Promise<BundleDefinition[]> {
    return await db.select().from(bundleDefinitions).where(eq(bundleDefinitions.workspaceId, workspaceId));
  }

  async getBundleDefinitionById(id: string): Promise<BundleDefinition | undefined> {
    const [bundle] = await db.select().from(bundleDefinitions).where(eq(bundleDefinitions.id, id));
    return bundle;
  }

  async updateBundleDefinition(id: string, bundle: Partial<InsertBundleDefinition>): Promise<BundleDefinition> {
    const [updated] = await db.update(bundleDefinitions)
      .set(bundle)
      .where(eq(bundleDefinitions.id, id))
      .returning();
    return updated;
  }

  async deleteBundleDefinition(id: string): Promise<void> {
    await db.delete(bundleDefinitions).where(eq(bundleDefinitions.id, id));
  }

  // Bundle Components
  async insertBundleComponent(component: InsertBundleComponent): Promise<BundleComponent> {
    const [newComponent] = await db.insert(bundleComponents).values(component).returning();
    return newComponent;
  }

  async getBundleComponentsByBundle(bundleId: string): Promise<BundleComponent[]> {
    return await db.select().from(bundleComponents).where(eq(bundleComponents.bundleId, bundleId));
  }

  async deleteBundleComponentsByBundle(bundleId: string): Promise<void> {
    await db.delete(bundleComponents).where(eq(bundleComponents.bundleId, bundleId));
  }

  async deleteBundleComponent(id: string): Promise<void> {
    await db.delete(bundleComponents).where(eq(bundleComponents.id, id));
  }

  // Order Bundle Records
  async insertOrderBundleRecord(record: InsertOrderBundleRecord): Promise<OrderBundleRecord> {
    const [newRecord] = await db.insert(orderBundleRecords).values(record).returning();
    return newRecord;
  }

  async getOrderBundleRecordsByOrder(orderId: string): Promise<OrderBundleRecord[]> {
    return await db.select().from(orderBundleRecords).where(eq(orderBundleRecords.orderId, orderId));
  }

  async getOrderBundleRecordById(id: string): Promise<OrderBundleRecord | undefined> {
    const [record] = await db.select().from(orderBundleRecords).where(eq(orderBundleRecords.id, id));
    return record;
  }

  // Order Bundle Assignments
  async insertOrderBundleAssignment(assignment: InsertOrderBundleAssignment): Promise<OrderBundleAssignment> {
    const [newAssignment] = await db.insert(orderBundleAssignments).values(assignment).returning();
    return newAssignment;
  }

  async getOrderBundleAssignmentsByRecord(orderBundleId: string): Promise<OrderBundleAssignment[]> {
    return await db.select().from(orderBundleAssignments).where(eq(orderBundleAssignments.orderBundleId, orderBundleId));
  }

  // Client Tag Definitions
  async insertClientTagDefinition(tag: InsertClientTagDefinition): Promise<ClientTagDefinition> {
    const [newTag] = await db.insert(clientTagDefinitions).values(tag).returning();
    return newTag;
  }

  async getClientTagDefinitionsByWorkspace(workspaceId: string): Promise<ClientTagDefinition[]> {
    return await db.select().from(clientTagDefinitions)
      .where(eq(clientTagDefinitions.workspaceId, workspaceId))
      .orderBy(clientTagDefinitions.sortOrder);
  }

  async getClientTagDefinitionById(id: string): Promise<ClientTagDefinition | undefined> {
    const [tag] = await db.select().from(clientTagDefinitions).where(eq(clientTagDefinitions.id, id));
    return tag;
  }

  async updateClientTagDefinition(id: string, tag: Partial<InsertClientTagDefinition>): Promise<ClientTagDefinition> {
    const [updated] = await db.update(clientTagDefinitions).set(tag).where(eq(clientTagDefinitions.id, id)).returning();
    return updated;
  }

  async deleteClientTagDefinition(id: string): Promise<void> {
    await db.delete(clientTagDefinitions).where(eq(clientTagDefinitions.id, id));
  }

  // Workspace Settings
  async getWorkspaceSettings(workspaceId: string): Promise<WorkspaceSettings | undefined> {
    const [settings] = await db.select().from(workspaceSettings).where(eq(workspaceSettings.workspaceId, workspaceId));
    return settings;
  }

  async upsertWorkspaceSettings(settings: InsertWorkspaceSettings): Promise<WorkspaceSettings> {
    const existing = await this.getWorkspaceSettings(settings.workspaceId);
    if (existing) {
      const [updated] = await db.update(workspaceSettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(workspaceSettings.workspaceId, settings.workspaceId))
        .returning();
      return updated;
    } else {
      const [newSettings] = await db.insert(workspaceSettings).values(settings).returning();
      return newSettings;
    }
  }

  async updateWorkspaceSettings(workspaceId: string, settings: Partial<InsertWorkspaceSettings>): Promise<WorkspaceSettings> {
    const [updated] = await db.update(workspaceSettings)
      .set({ ...settings, updatedAt: new Date() })
      .where(eq(workspaceSettings.workspaceId, workspaceId))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
