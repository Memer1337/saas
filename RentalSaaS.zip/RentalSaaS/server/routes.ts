import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcrypt";
import { z } from "zod";
import { storage } from "./storage";
import {
  type User,
  insertUserSchema,
  insertClientSchema,
  insertEquipmentTypeSchema,
  insertEquipmentItemSchema,
  insertTariffSchema,
  insertCalendarSchema,
  insertOrderSchema,
  insertPaymentSchema,
  insertDiscountSchema,
  insertLocationSchema,
  insertBundleDefinitionSchema,
  insertBundleComponentSchema,
  insertClientTagDefinitionSchema,
  insertWorkspaceSettingsSchema,
} from "@shared/schema";
import pgSession from "connect-pg-simple";
import { pool } from "./db";

const PgSession = pgSession(session);
const SALT_ROUNDS = 10;

// Password hashing with bcrypt
async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, SALT_ROUNDS);
}

async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(
    session({
      store: new PgSession({
        pool,
        tableName: "user_sessions",
        createTableIfMissing: true,
      }),
      secret: process.env.SESSION_SECRET || "dev-secret-change-in-production",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
      },
    })
  );

  // Passport configuration
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username" });
        }
        const isValid = await verifyPassword(password, user.password);
        if (!isValid) {
          return done(null, false, { message: "Incorrect password" });
        }
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUserById(id);
      done(null, user || null);
    } catch (error) {
      done(error);
    }
  });

  app.use(passport.initialize());
  app.use(passport.session());

  // Auth middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    next();
  };

  // Authentication routes
  app.post("/api/register", async (req, res) => {
    try {
      // Create schema that omits server-controlled fields
      const registerSchema = insertUserSchema.omit({
        id: true,
        workspaceId: true,
        locationId: true,
        role: true,
      });
      
      const validated = registerSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(validated.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      // Create new workspace for this user
      const workspace = await storage.insertWorkspace({
        name: `${validated.username}'s Workspace`,
      });

      // Create default location for the workspace
      const location = await storage.insertLocation({
        workspaceId: workspace.id,
        name: "Main Location",
      });

      const hashedPassword = await hashPassword(validated.password);
      const user = await storage.insertUser({
        ...validated,
        password: hashedPassword,
        workspaceId: workspace.id,
        locationId: location.id,
        role: "SUPERADMIN",
      });

      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ error: "Login failed after registration" });
        }
        res.json({ ...user, password: undefined });
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    const user = req.user as User;
    res.json({ ...user, password: undefined });
  });

  app.post("/api/logout", (req, res) => {
    req.logout(() => {
      res.json({ success: true });
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    const user = req.user as User;
    res.json({ ...user, password: undefined });
  });

  // Workspaces routes
  app.post("/api/workspaces", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      // Only SUPERADMIN can create workspaces
      if (user.role !== "SUPERADMIN") {
        return res.status(403).json({ error: "Forbidden" });
      }
      
      const validated = insertWorkspaceSchema.parse(req.body);
      const workspace = await storage.insertWorkspace(validated);
      res.json(workspace);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Locations routes
  app.get("/api/locations", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const locations = await storage.getLocationsByWorkspace(user.workspaceId);
      res.json(locations);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/locations", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertLocationSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const location = await storage.insertLocation(validated);
      res.json(location);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Clients routes
  app.get("/api/clients", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const clients = await storage.getClientsByWorkspace(user.workspaceId);
      res.json(clients);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/clients", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertClientSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const client = await storage.insertClient(validated);
      res.json(client);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/clients/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user as User;
      
      // Verify client belongs to user's workspace
      const existingClient = await storage.getClientById(id);
      if (!existingClient || existingClient.workspaceId !== user.workspaceId) {
        return res.status(404).json({ error: "Client not found" });
      }

      // Validate and exclude server-controlled fields (workspaceId, id, createdAt)
      const validated = insertClientSchema.partial().omit({ workspaceId: true }).parse(req.body);
      const updated = await storage.updateClient(id, validated);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/clients/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user as User;
      
      // Verify client belongs to user's workspace
      const existingClient = await storage.getClientById(id);
      if (!existingClient || existingClient.workspaceId !== user.workspaceId) {
        return res.status(404).json({ error: "Client not found" });
      }

      await storage.deleteClient(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Equipment Types routes
  app.get("/api/equipment-types", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const types = await storage.getEquipmentTypesByWorkspace(user.workspaceId);
      res.json(types);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/equipment-types", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertEquipmentTypeSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const type = await storage.insertEquipmentType(validated);
      res.json(type);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Equipment Items routes
  app.get("/api/equipment-items", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const { itemNumber } = req.query;
      
      if (itemNumber && typeof itemNumber === 'string') {
        const items = await storage.getEquipmentItemByItemNumber(user.workspaceId, itemNumber);
        res.json(items);
      } else {
        const items = await storage.getEquipmentItemsByWorkspace(user.workspaceId);
        res.json(items);
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/equipment-items", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertEquipmentItemSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const item = await storage.insertEquipmentItem(validated);
      res.json(item);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/equipment-items/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const item = await storage.updateEquipmentItem(id, req.body);
      res.json(item);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/equipment-items/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteEquipmentItem(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Tariffs routes
  app.get("/api/tariffs", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const tariffs = await storage.getTariffsByWorkspace(user.workspaceId);
      res.json(tariffs);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/tariffs/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user as User;
      
      // Get existing tariff to verify workspace ownership
      const existingTariffs = await storage.getTariffsByWorkspace(user.workspaceId);
      const existingTariff = existingTariffs.find(t => t.id === id);
      
      if (!existingTariff) {
        return res.status(404).json({ error: "Tariff not found" });
      }

      // Validate input - exclude workspaceId, equipmentTypeId, bundleId from updates
      const validated = insertTariffSchema.partial().omit({ 
        workspaceId: true,
        equipmentTypeId: true,
        bundleId: true,
      }).parse(req.body);
      
      const updated = await storage.updateTariff(id, validated);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/tariffs", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertTariffSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const tariff = await storage.insertTariff(validated);
      res.json(tariff);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Calendar routes
  app.get("/api/calendar", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const calendar = await storage.getCalendarByWorkspace(user.workspaceId);
      res.json(calendar);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/calendar", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertCalendarSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const day = await storage.insertCalendarDay(validated);
      res.json(day);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/calendar/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user as User;
      
      // Check if calendar day exists and belongs to user's workspace
      const existingDay = await storage.getCalendarDayById(id);
      if (!existingDay) {
        return res.status(404).json({ error: "Calendar day not found" });
      }
      if (existingDay.workspaceId !== user.workspaceId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const validated = insertCalendarSchema.partial().omit({ workspaceId: true }).parse(req.body);
      const updated = await storage.updateCalendarDay(id, validated);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/calendar/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user as User;
      
      // Check if calendar day exists and belongs to user's workspace
      const existingDay = await storage.getCalendarDayById(id);
      if (!existingDay) {
        return res.status(404).json({ error: "Calendar day not found" });
      }
      if (existingDay.workspaceId !== user.workspaceId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      await storage.deleteCalendarDay(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Orders routes
  app.get("/api/orders", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const orders = await storage.getOrdersByWorkspace(user.workspaceId);
      res.json(orders);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/orders", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const { items, discountPercent, ...orderData } = req.body;
      
      // Generate order number
      const timestamp = Date.now();
      const orderNumber = `ORD-${timestamp}`;

      // Create validation schema that accepts ISO string dates
      const createOrderSchema = insertOrderSchema.extend({
        startTime: z.coerce.date(),
        endTime: z.coerce.date(),
      });

      // Validate basic order data
      const startTime = new Date(orderData.startTime);
      const endTime = new Date(orderData.endTime);
      
      // Get tariffs for pricing calculation
      const tariffs = await storage.getTariffsByWorkspace(user.workspaceId);
      
      // Calculate server-side pricing
      const minutes = Math.ceil((endTime.getTime() - startTime.getTime()) / (1000 * 60));
      const dayType = startTime.getDay() === 0 || startTime.getDay() === 6 ? "WEEKEND" : "WEEKDAY";
      
      let calculatedSubtotal = 0;
      const validatedItems = [];
      
      for (const item of items || []) {
        // Find matching tariff
        const tariff = tariffs.find(t => 
          t.equipmentTypeId === item.equipmentTypeId &&
          t.category === item.category &&
          t.dayType === dayType
        );
        
        if (!tariff) {
          throw new Error(`No tariff found for equipment ${item.equipmentTypeId} ${item.category} ${dayType}`);
        }
        
        // Calculate item price
        const basePrice = parseFloat(tariff.basePrice);
        const incrementPrice = parseFloat(tariff.incrementPrice);
        const incrementMinutes = tariff.incrementMinutes;
        
        let itemPrice = basePrice;
        const additionalMinutes = Math.max(0, minutes - incrementMinutes);
        const increments = Math.ceil(additionalMinutes / incrementMinutes);
        itemPrice += increments * incrementPrice;
        itemPrice *= item.quantity;
        
        if (!item.isFree) {
          calculatedSubtotal += itemPrice;
        }
        
        validatedItems.push({
          equipmentTypeId: item.equipmentTypeId,
          category: item.category,
          quantity: item.quantity,
          price: item.isFree ? "0" : itemPrice.toString(),
          isFree: item.isFree || false,
          freeReason: item.freeReason || null,
        });
      }
      
      // Apply discount
      const discount = discountPercent ? (calculatedSubtotal * (discountPercent / 100)) : 0;
      const calculatedTotal = calculatedSubtotal - discount;

      // Validate order data with server-calculated pricing
      const validated = createOrderSchema.parse({
        ...orderData,
        orderNumber,
        status: "DRAFT",
        workspaceId: user.workspaceId,
        locationId: orderData.locationId || user.locationId || user.workspaceId,
        createdById: user.id,
        subtotal: calculatedSubtotal.toString(),
        discountPercent: discountPercent || 0,
        discountFixed: "0",
        total: calculatedTotal.toString(),
      });

      // Create order
      const order = await storage.insertOrder(validated);

      // Create order items with validated prices
      for (const item of validatedItems) {
        await storage.insertOrderItem({
          orderId: order.id,
          equipmentTypeId: item.equipmentTypeId,
          equipmentItemId: null,
          category: item.category,
          quantity: item.quantity,
          price: item.price,
          isFree: item.isFree,
          freeReason: item.freeReason,
        });
      }

      res.json(order);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/orders/:id", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const orderId = req.params.id;
      const { items, discountPercent, ...orderData } = req.body;
      
      // Verify order exists and belongs to workspace
      const existingOrder = await storage.getOrderById(orderId);
      if (!existingOrder || existingOrder.workspaceId !== user.workspaceId) {
        return res.status(404).json({ error: "Order not found" });
      }

      // Validate and calculate pricing (same as POST)
      const startTime = new Date(orderData.startTime);
      const endTime = new Date(orderData.endTime);
      
      const tariffs = await storage.getTariffsByWorkspace(user.workspaceId);
      const minutes = Math.ceil((endTime.getTime() - startTime.getTime()) / (1000 * 60));
      const dayType = startTime.getDay() === 0 || startTime.getDay() === 6 ? "WEEKEND" : "WEEKDAY";
      
      let calculatedSubtotal = 0;
      const validatedItems = [];
      
      for (const item of items || []) {
        const tariff = tariffs.find(t => 
          t.equipmentTypeId === item.equipmentTypeId &&
          t.category === item.category &&
          t.dayType === dayType
        );
        
        if (!tariff) {
          throw new Error(`No tariff found for equipment ${item.equipmentTypeId} ${item.category} ${dayType}`);
        }
        
        const basePrice = parseFloat(tariff.basePrice);
        const incrementPrice = parseFloat(tariff.incrementPrice);
        const incrementMinutes = tariff.incrementMinutes;
        
        let itemPrice = basePrice;
        const additionalMinutes = Math.max(0, minutes - incrementMinutes);
        const increments = Math.ceil(additionalMinutes / incrementMinutes);
        itemPrice += increments * incrementPrice;
        itemPrice *= item.quantity;
        
        if (!item.isFree) {
          calculatedSubtotal += itemPrice;
        }
        
        validatedItems.push({
          equipmentTypeId: item.equipmentTypeId,
          category: item.category,
          quantity: item.quantity,
          price: item.isFree ? "0" : itemPrice.toString(),
          isFree: item.isFree || false,
          freeReason: item.freeReason || null,
        });
      }
      
      const discount = discountPercent ? (calculatedSubtotal * (discountPercent / 100)) : 0;
      const calculatedTotal = calculatedSubtotal - discount;

      // Update order
      await storage.updateOrder(orderId, {
        clientId: orderData.clientId,
        startTime,
        endTime,
        subtotal: calculatedSubtotal.toString(),
        discountPercent: discountPercent || 0,
        discountFixed: "0",
        total: calculatedTotal.toString(),
        notes: orderData.notes,
      });

      // Delete old order items and create new ones
      await storage.deleteOrderItemsByOrder(orderId);
      for (const item of validatedItems) {
        await storage.insertOrderItem({
          orderId,
          equipmentTypeId: item.equipmentTypeId,
          equipmentItemId: null,
          category: item.category,
          quantity: item.quantity,
          price: item.price,
          isFree: item.isFree,
          freeReason: item.freeReason,
        });
      }

      const updatedOrder = await storage.getOrderById(orderId);
      res.json(updatedOrder);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/orders/:id/status", requireAuth, async (req, res) => {
    try {
      const { status } = req.body;
      await storage.updateOrderStatus(req.params.id, status);
      const order = await storage.getOrderById(req.params.id);
      res.json(order);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Order Items routes
  app.get("/api/order-items", requireAuth, async (req, res) => {
    try {
      const { orderId } = req.query;
      if (!orderId || typeof orderId !== 'string') {
        return res.status(400).json({ error: "orderId query parameter is required" });
      }
      const items = await storage.getOrderItemsByOrder(orderId);
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Payments routes
  app.post("/api/payments", requireAuth, async (req, res) => {
    try {
      const validated = insertPaymentSchema.parse(req.body);
      const payment = await storage.insertPayment(validated);
      res.json(payment);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Discounts routes
  app.get("/api/discounts", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const discounts = await storage.getDiscountsByWorkspace(user.workspaceId);
      res.json(discounts);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/discounts", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertDiscountSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const discount = await storage.insertDiscount(validated);
      res.json(discount);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Bundle Definitions routes
  app.get("/api/bundles", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const bundles = await storage.getBundleDefinitionsByWorkspace(user.workspaceId);
      res.json(bundles);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/bundles/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const bundle = await storage.getBundleDefinitionById(id);
      if (!bundle) {
        return res.status(404).json({ error: "Bundle not found" });
      }
      res.json(bundle);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/bundles", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertBundleDefinitionSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const bundle = await storage.insertBundleDefinition(validated);
      res.json(bundle);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/bundles/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const bundle = await storage.updateBundleDefinition(id, req.body);
      res.json(bundle);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/bundles/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteBundleDefinition(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Bundle Components routes
  app.get("/api/bundles/:bundleId/components", requireAuth, async (req, res) => {
    try {
      const { bundleId } = req.params;
      const components = await storage.getBundleComponentsByBundle(bundleId);
      res.json(components);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/bundles/:bundleId/components", requireAuth, async (req, res) => {
    try {
      const { bundleId } = req.params;
      const validated = insertBundleComponentSchema.parse({
        ...req.body,
        bundleId,
      });
      const component = await storage.insertBundleComponent(validated);
      res.json(component);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/bundle-components/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteBundleComponent(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Client Tag Definitions routes
  app.get("/api/client-tags", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const tags = await storage.getClientTagDefinitionsByWorkspace(user.workspaceId);
      res.json(tags);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/client-tags", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertClientTagDefinitionSchema.parse({
        ...req.body,
        workspaceId: user.workspaceId,
      });
      const tag = await storage.insertClientTagDefinition(validated);
      res.json(tag);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/client-tags/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user as User;
      
      // Verify tag belongs to user's workspace
      const existingTag = await storage.getClientTagDefinitionById(id);
      if (!existingTag || existingTag.workspaceId !== user.workspaceId) {
        return res.status(404).json({ error: "Client tag not found" });
      }

      const validated = insertClientTagDefinitionSchema.partial().omit({ workspaceId: true }).parse(req.body);
      const updated = await storage.updateClientTagDefinition(id, validated);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/client-tags/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user as User;
      
      // Verify tag belongs to user's workspace
      const existingTag = await storage.getClientTagDefinitionById(id);
      if (!existingTag || existingTag.workspaceId !== user.workspaceId) {
        return res.status(404).json({ error: "Client tag not found" });
      }

      await storage.deleteClientTagDefinition(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Workspace Settings routes
  app.get("/api/workspace-settings", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const settings = await storage.getWorkspaceSettings(user.workspaceId);
      res.json(settings || {});
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/workspace-settings", requireAuth, async (req, res) => {
    try {
      const user = req.user as User;
      const validated = insertWorkspaceSettingsSchema.partial().parse(req.body);
      const settings = await storage.upsertWorkspaceSettings({
        workspaceId: user.workspaceId,
        ...validated,
      });
      res.json(settings);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Equipment Types management (PATCH and DELETE for admin customization)
  app.patch("/api/equipment-types/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user as User;
      
      // Get existing type to verify workspace
      const types = await storage.getEquipmentTypesByWorkspace(user.workspaceId);
      const existing = types.find(t => t.id === id);
      
      if (!existing) {
        return res.status(404).json({ error: "Equipment type not found" });
      }

      const validated = insertEquipmentTypeSchema.partial().omit({ workspaceId: true }).parse(req.body);
      
      // Since we don't have updateEquipmentType in storage, we'll use insert temporarily
      // In production, add updateEquipmentType to storage interface
      const updated = await storage.insertEquipmentType({
        ...existing,
        ...validated,
        workspaceId: user.workspaceId,
      });
      
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
