import { storage } from "./storage";
import bcrypt from "bcrypt";

const SALT_ROUNDS = 10;

async function seed() {
  console.log("🌱 Seeding database...");

  try {
    // Create demo workspace
    const workspace = await storage.insertWorkspace({
      name: "Demo Rental Point",
    });
    console.log(`✅ Created workspace: ${workspace.name}`);

    // Create demo location
    const location = await storage.insertLocation({
      workspaceId: workspace.id,
      name: "Main Location",
    });
    console.log(`✅ Created location: ${location.name}`);

    // Create demo admin user
    const adminPassword = await bcrypt.hash("admin123", SALT_ROUNDS);
    const admin = await storage.insertUser({
      username: "admin",
      password: adminPassword,
      workspaceId: workspace.id,
      role: "SUPERADMIN",
      locationId: location.id,
    });
    console.log(`✅ Created admin user: ${admin.username} (password: admin123)`);

    // Create equipment types (physical inventory only, NO bundles)
    const equipmentTypesData = [
      { name: "Лыжи", rentalMode: "HOURLY" as const, isBundle: false },
      { name: "Сноуборд", rentalMode: "HOURLY" as const, isBundle: false },
      { name: "Ботинки", rentalMode: "HOURLY" as const, isBundle: false },
      { name: "Палки", rentalMode: "DAILY_ONLY" as const, isBundle: false },
      { name: "Премиум", rentalMode: "HOURLY" as const, isBundle: false },
      { name: "Шлем", rentalMode: "DAILY_ONLY" as const, isBundle: false },
      { name: "Маска", rentalMode: "DAILY_ONLY" as const, isBundle: false },
    ];

    const equipmentTypesMap = new Map();
    for (const data of equipmentTypesData) {
      const type = await storage.insertEquipmentType({
        ...data,
        workspaceId: workspace.id,
      });
      equipmentTypesMap.set(data.name, type);
      console.log(`✅ Created equipment type: ${type.name}`);
    }

    // Create bundle definitions (billing groups, NOT inventory) - BEFORE tariffs
    const bundlesData = [
      { 
        name: "Комплект лыжи", 
        description: "Лыжи + Ботинки + Палки",
        rentalMode: "HOURLY" as const,
        defaultCategory: null,
        autoAssign: true,
        components: [
          { typeName: "Лыжи", quantity: 1, isOptional: false, sequence: 1 },
          { typeName: "Ботинки", quantity: 1, isOptional: false, sequence: 2 },
          { typeName: "Палки", quantity: 1, isOptional: true, sequence: 3 },
        ]
      },
      { 
        name: "Комплект сноуборд", 
        description: "Сноуборд + Ботинки",
        rentalMode: "HOURLY" as const,
        defaultCategory: null,
        autoAssign: true,
        components: [
          { typeName: "Сноуборд", quantity: 1, isOptional: false, sequence: 1 },
          { typeName: "Ботинки", quantity: 1, isOptional: false, sequence: 2 },
        ]
      },
    ];

    const bundlesMap = new Map();
    for (const bundleData of bundlesData) {
      const bundle = await storage.insertBundleDefinition({
        workspaceId: workspace.id,
        name: bundleData.name,
        description: bundleData.description,
        rentalMode: bundleData.rentalMode,
        defaultCategory: bundleData.defaultCategory,
        autoAssign: bundleData.autoAssign,
      });
      bundlesMap.set(bundleData.name, bundle);

      for (const comp of bundleData.components) {
        const equipmentType = equipmentTypesMap.get(comp.typeName);
        if (!equipmentType) continue;

        await storage.insertBundleComponent({
          bundleId: bundle.id,
          equipmentTypeId: equipmentType.id,
          quantity: comp.quantity,
          isOptional: comp.isOptional,
          sequence: comp.sequence,
        });
      }
      console.log(`✅ Created bundle: ${bundle.name}`);
    }

    // Create tariffs with new prices
    const tariffsData = [
      // Bundle tariffs (Комплект лыжи / Комплект сноуборд)
      { bundle: "Комплект лыжи", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "2000", incrementMinutes: 30, incrementPrice: "500" },
      { bundle: "Комплект лыжи", category: "CHILD" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "1500", incrementMinutes: 30, incrementPrice: "250" },
      { bundle: "Комплект лыжи", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "2500", incrementMinutes: 30, incrementPrice: "500" },
      { bundle: "Комплект лыжи", category: "CHILD" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1500", incrementMinutes: 30, incrementPrice: "250" },
      
      { bundle: "Комплект сноуборд", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "2000", incrementMinutes: 30, incrementPrice: "500" },
      { bundle: "Комплект сноуборд", category: "CHILD" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "1500", incrementMinutes: 30, incrementPrice: "250" },
      { bundle: "Комплект сноуборд", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "2500", incrementMinutes: 30, incrementPrice: "500" },
      { bundle: "Комплект сноуборд", category: "CHILD" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1500", incrementMinutes: 30, incrementPrice: "250" },

      // Лыжи (отдельно)
      { type: "Лыжи", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "1200", incrementMinutes: 30, incrementPrice: "300" },
      { type: "Лыжи", category: "CHILD" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "800", incrementMinutes: 30, incrementPrice: "200" },
      { type: "Лыжи", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1400", incrementMinutes: 30, incrementPrice: "400" },
      { type: "Лыжи", category: "CHILD" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1000", incrementMinutes: 30, incrementPrice: "300" },

      // Сноуборд (отдельно)
      { type: "Сноуборд", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "1200", incrementMinutes: 30, incrementPrice: "300" },
      { type: "Сноуборд", category: "CHILD" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "800", incrementMinutes: 30, incrementPrice: "200" },
      { type: "Сноуборд", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1400", incrementMinutes: 30, incrementPrice: "400" },
      { type: "Сноуборд", category: "CHILD" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1000", incrementMinutes: 30, incrementPrice: "300" },

      // Ботинки (горнолыжные/сноубордические)
      { type: "Ботинки", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "1200", incrementMinutes: 30, incrementPrice: "300" },
      { type: "Ботинки", category: "CHILD" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "800", incrementMinutes: 30, incrementPrice: "200" },
      { type: "Ботинки", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1400", incrementMinutes: 30, incrementPrice: "400" },
      { type: "Ботинки", category: "CHILD" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1000", incrementMinutes: 30, incrementPrice: "300" },

      // Премиум (инвентарь повышенного класса, только взрослый)
      { type: "Премиум", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 1, basePrice: "1700", incrementMinutes: 30, incrementPrice: "500" },
      { type: "Премиум", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 1, basePrice: "1800", incrementMinutes: 30, incrementPrice: "700" },

      // Шлем (дневная аренда)
      { type: "Шлем", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 24, basePrice: "500", incrementMinutes: 0, incrementPrice: "0" },
      { type: "Шлем", category: "CHILD" as const, dayType: "WEEKDAY" as const, baseHours: 24, basePrice: "300", incrementMinutes: 0, incrementPrice: "0" },
      { type: "Шлем", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 24, basePrice: "600", incrementMinutes: 0, incrementPrice: "0" },
      { type: "Шлем", category: "CHILD" as const, dayType: "WEEKEND" as const, baseHours: 24, basePrice: "400", incrementMinutes: 0, incrementPrice: "0" },

      // Маска (очки, дневная аренда, единая цена)
      { type: "Маска", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 24, basePrice: "600", incrementMinutes: 0, incrementPrice: "0" },
      { type: "Маска", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 24, basePrice: "800", incrementMinutes: 0, incrementPrice: "0" },

      // Палки (дневная аренда, единая цена)
      { type: "Палки", category: "ADULT" as const, dayType: "WEEKDAY" as const, baseHours: 24, basePrice: "400", incrementMinutes: 0, incrementPrice: "0" },
      { type: "Палки", category: "ADULT" as const, dayType: "WEEKEND" as const, baseHours: 24, basePrice: "500", incrementMinutes: 0, incrementPrice: "0" },
    ];

    for (const data of tariffsData) {
      const tariffData: any = {
        workspaceId: workspace.id,
        category: data.category,
        dayType: data.dayType,
        baseHours: data.baseHours,
        basePrice: data.basePrice,
        incrementMinutes: data.incrementMinutes,
        incrementPrice: data.incrementPrice,
      };

      if ('bundle' in data) {
        const bundle = bundlesMap.get(data.bundle);
        if (bundle) {
          tariffData.bundleId = bundle.id;
          tariffData.equipmentTypeId = null;
        }
      } else if ('type' in data) {
        const equipmentType = equipmentTypesMap.get(data.type);
        if (equipmentType) {
          tariffData.equipmentTypeId = equipmentType.id;
          tariffData.bundleId = null;
        }
      }

      if (tariffData.equipmentTypeId || tariffData.bundleId) {
        await storage.insertTariff(tariffData);
      }
    }
    console.log(`✅ Created ${tariffsData.length} tariffs`);

    // Create sample equipment items (NO bundles - only physical inventory)
    const itemsData = [
      { type: "Лыжи", count: 15 },
      { type: "Сноуборд", count: 8 },
      { type: "Ботинки", count: 20 },
      { type: "Палки", count: 12 },
      { type: "Премиум", count: 5 },
      { type: "Шлем", count: 15 },
      { type: "Маска", count: 10 },
    ];

    let totalItems = 0;
    for (const data of itemsData) {
      const equipmentType = equipmentTypesMap.get(data.type);
      if (!equipmentType) continue;

      for (let i = 1; i <= data.count; i++) {
        await storage.insertEquipmentItem({
          workspaceId: workspace.id,
          locationId: location.id,
          equipmentTypeId: equipmentType.id,
          itemNumber: `${data.type.substring(0, 3).toUpperCase()}-${String(i).padStart(3, '0')}`,
          status: "AVAILABLE",
          notes: null,
        });
        totalItems++;
      }
    }
    console.log(`✅ Created ${totalItems} equipment items`);

    // Create sample clients
    const clientsData = [
      { fullName: "Иванов Иван Иванович", phone: "+7 (999) 123-45-67", email: "ivanov@example.com", tags: [] },
      { fullName: "Петрова Мария Сергеевна", phone: "+7 (999) 234-56-78", email: "petrova@example.com", tags: ["STUDENT_SCHOOL"] },
      { fullName: "Сидоров Петр Алексеевич", phone: "+7 (999) 345-67-89", email: "sidorov@example.com", tags: ["VIP"] },
      { fullName: "Смирнова Елена Дмитриевна", phone: "+7 (999) 456-78-90", email: "smirnova@example.com", tags: ["SUBSCRIPTION"] },
      { fullName: "Кузнецов Алексей Владимирович", phone: "+7 (999) 567-89-01", email: "kuznetsov@example.com", tags: ["PRIVILEGED"] },
    ];

    for (const data of clientsData) {
      await storage.insertClient({
        workspaceId: workspace.id,
        fullName: data.fullName,
        phone: data.phone,
        email: data.email,
        tags: data.tags,
        notes: null,
      });
    }
    console.log(`✅ Created ${clientsData.length} sample clients`);

    // Create discounts
    const discountsData = [
      { code: "SCHOOL10", name: "Школьный урок", percent: 10, requiresTag: "STUDENT_SCHOOL" },
      { code: "SUB20", name: "Абонемент", percent: 20, requiresTag: "SUBSCRIPTION" },
      { code: "STUDENT20", name: "Студенты вторник", percent: 20, requiresTag: "STUDENT_UNIVERSITY" },
      { code: "PRIVILEGE35", name: "Льготники", percent: 35, requiresTag: "PRIVILEGED" },
      { code: "PROMO35", name: "Промо 35%", percent: 35, requiresTag: null },
      { code: "PROMO50", name: "Промо 50%", percent: 50, requiresTag: null },
      { code: "PROMO100", name: "Промо 100%", percent: 100, requiresTag: null },
    ];

    for (const data of discountsData) {
      await storage.insertDiscount({
        workspaceId: workspace.id,
        code: data.code,
        name: data.name,
        percent: data.percent,
        isActive: true,
        requiresTag: data.requiresTag,
      });
    }
    console.log(`✅ Created ${discountsData.length} discount codes`);

    console.log("\n🎉 Database seeded successfully!");
    console.log("\n📝 Login credentials:");
    console.log("   Username: admin");
    console.log("   Password: admin123");
    console.log(`   Workspace ID: ${workspace.id}\n`);

    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  }
}

seed();
