import { db } from "../server/db";
import { calendar } from "../shared/schema";
import { eq, and, gte, lte } from "drizzle-orm";

/**
 * Официальный производственный календарь РФ на 2025 год
 * Источник: Постановление Правительства РФ от 04.10.2024 № 1335
 */

const HOLIDAYS_2025 = [
  // Новогодние каникулы
  { date: "2025-01-01", name: "Новый год", dayType: "HOLIDAY" as const },
  { date: "2025-01-02", name: "Новогодние каникулы", dayType: "HOLIDAY" as const },
  { date: "2025-01-03", name: "Новогодние каникулы", dayType: "HOLIDAY" as const },
  { date: "2025-01-04", name: "Новогодние каникулы", dayType: "HOLIDAY" as const },
  { date: "2025-01-05", name: "Новогодние каникулы", dayType: "HOLIDAY" as const },
  { date: "2025-01-06", name: "Новогодние каникулы", dayType: "HOLIDAY" as const },
  { date: "2025-01-07", name: "Рождество Христово", dayType: "HOLIDAY" as const },
  { date: "2025-01-08", name: "Новогодние каникулы", dayType: "HOLIDAY" as const },
  
  // День защитника Отечества
  { date: "2025-02-23", name: "День защитника Отечества", dayType: "HOLIDAY" as const },
  { date: "2025-02-24", name: "Выходной (перенос с воскр.)", dayType: "WEEKEND" as const },
  
  // Международный женский день
  { date: "2025-03-08", name: "Международный женский день", dayType: "HOLIDAY" as const },
  { date: "2025-03-09", name: "Выходной (воскр.)", dayType: "WEEKEND" as const },
  { date: "2025-03-10", name: "Выходной (понед.)", dayType: "WEEKEND" as const },
  
  // Праздник Весны и Труда
  { date: "2025-05-01", name: "Праздник Весны и Труда", dayType: "HOLIDAY" as const },
  { date: "2025-05-02", name: "Выходной (перенос с 4 янв)", dayType: "WEEKEND" as const },
  { date: "2025-05-03", name: "Выходной (суб.)", dayType: "WEEKEND" as const },
  { date: "2025-05-04", name: "Выходной (воскр.)", dayType: "WEEKEND" as const },
  
  // День Победы
  { date: "2025-05-08", name: "Выходной (перенос с 23 фев)", dayType: "WEEKEND" as const },
  { date: "2025-05-09", name: "День Победы", dayType: "HOLIDAY" as const },
  { date: "2025-05-10", name: "Выходной (суб.)", dayType: "WEEKEND" as const },
  { date: "2025-05-11", name: "Выходной (воскр.)", dayType: "WEEKEND" as const },
  
  // День России
  { date: "2025-06-12", name: "День России", dayType: "HOLIDAY" as const },
  { date: "2025-06-13", name: "Выходной (перенос с 8 мар)", dayType: "WEEKEND" as const },
  { date: "2025-06-14", name: "Выходной (суб.)", dayType: "WEEKEND" as const },
  { date: "2025-06-15", name: "Выходной (воскр.)", dayType: "WEEKEND" as const },
  
  // День народного единства
  { date: "2025-11-03", name: "Выходной (перенос с 1 ноя)", dayType: "WEEKEND" as const },
  { date: "2025-11-04", name: "День народного единства", dayType: "HOLIDAY" as const },
  
  // Новогодний перенос (31 декабря)
  { date: "2025-12-31", name: "Выходной (перенос с 5 янв)", dayType: "WEEKEND" as const },
];

async function populateCalendar2025() {
  console.log("🗓️  Заполнение календаря РФ на 2025 год...\n");

  try {
    // Получаем первый workspace (для demo целей)
    const workspaces = await db.query.workspaces.findMany({ limit: 1 });
    
    if (workspaces.length === 0) {
      console.error("❌ Не найдено ни одного workspace!");
      process.exit(1);
    }

    const workspaceId = workspaces[0].id;
    console.log(`✅ Используем workspace: ${workspaces[0].name} (${workspaceId})\n`);

    // Очищаем существующие записи на 2025 год для этого workspace
    console.log("🧹 Очистка существующих записей на 2025 год...");
    await db.delete(calendar).where(
      and(
        eq(calendar.workspaceId, workspaceId),
        gte(calendar.date, new Date("2025-01-01")),
        lte(calendar.date, new Date("2025-12-31"))
      )
    );

    // Добавляем новые записи
    console.log("📝 Добавление праздничных и выходных дней...\n");
    
    for (const day of HOLIDAYS_2025) {
      const icon = day.dayType === "HOLIDAY" ? "🎉" : "📅";
      await db.insert(calendar).values({
        workspaceId,
        date: new Date(day.date),
        dayType: day.dayType,
        name: day.name,
      });
      console.log(`${icon} ${day.date} - ${day.name} (${day.dayType})`);
    }

    console.log(`\n✅ Успешно добавлено ${HOLIDAYS_2025.length} дней в календарь!`);
    console.log("\n📊 Статистика:");
    console.log(`   - Праздников: ${HOLIDAYS_2025.filter(d => d.dayType === "HOLIDAY").length}`);
    console.log(`   - Переносов выходных: ${HOLIDAYS_2025.filter(d => d.dayType === "WEEKEND").length}`);
    
    process.exit(0);
  } catch (error) {
    console.error("❌ Ошибка при заполнении календаря:", error);
    process.exit(1);
  }
}

populateCalendar2025();
