import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, decimal, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum("user_role", ["SUPERADMIN", "MANAGER", "CASHIER"]);
export const orderStatusEnum = pgEnum("order_status", ["DRAFT", "OPEN", "PAID", "CLOSED", "CANCELLED"]);
export const equipmentStatusEnum = pgEnum("equipment_status", ["AVAILABLE", "RENTED", "SERVICE", "LOST"]);
export const paymentTypeEnum = pgEnum("payment_type", ["CASH", "CARD", "ONLINE"]);
export const dayTypeEnum = pgEnum("day_type", ["WEEKDAY", "WEEKEND", "HOLIDAY"]);
export const rentalModeEnum = pgEnum("rental_mode", ["HOURLY", "DAILY", "DAILY_ONLY"]);
export const categoryEnum = pgEnum("category", ["ADULT", "CHILD"]);
export const clientTagEnum = pgEnum("client_tag", ["STUDENT_SCHOOL", "STUDENT_UNIVERSITY", "PRIVILEGED", "VIP", "SUBSCRIPTION"]);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").notNull().default("CASHIER"),
  workspaceId: varchar("workspace_id").notNull(),
  locationId: varchar("location_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Workspaces table (multi-tenant)
export const workspaces = pgTable("workspaces", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Locations table (rental points)
export const locations = pgTable("locations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Clients table
export const clients = pgTable("clients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  email: text("email"),
  tags: text("tags").array().default(sql`ARRAY[]::text[]`),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Equipment types (лыжи, сноуборд, ботинки, палки, etc.)
export const equipmentTypes = pgTable("equipment_types", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  name: text("name").notNull(),
  rentalMode: rentalModeEnum("rental_mode").notNull().default("HOURLY"),
  isBundle: boolean("is_bundle").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Bundle definitions (комплект = лыжи + ботинки + палки)
export const bundleDefinitions = pgTable("bundle_definitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  rentalMode: rentalModeEnum("rental_mode").notNull().default("HOURLY"),
  defaultCategory: categoryEnum("default_category"),
  autoAssign: boolean("auto_assign").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Bundle components (что входит в комплект)
export const bundleComponents = pgTable("bundle_components", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  bundleId: varchar("bundle_id").notNull(),
  equipmentTypeId: varchar("equipment_type_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  isOptional: boolean("is_optional").notNull().default(false),
  sequence: integer("sequence").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Equipment items (конкретные единицы инвентаря)
export const equipmentItems = pgTable("equipment_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  locationId: varchar("location_id").notNull(),
  equipmentTypeId: varchar("equipment_type_id").notNull(),
  itemNumber: text("item_number").notNull(),
  barcode: text("barcode").unique(),
  status: equipmentStatusEnum("status").notNull().default("AVAILABLE"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Tariffs (цены для оборудования и комплектов)
export const tariffs = pgTable("tariffs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  equipmentTypeId: varchar("equipment_type_id"),
  bundleId: varchar("bundle_id"),
  category: categoryEnum("category").notNull(),
  dayType: dayTypeEnum("day_type").notNull(),
  baseHours: integer("base_hours").notNull().default(1),
  basePrice: decimal("base_price", { precision: 10, scale: 2 }).notNull(),
  incrementMinutes: integer("increment_minutes").notNull().default(30),
  incrementPrice: decimal("increment_price", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Calendar (праздники и особые дни)
export const calendar = pgTable("calendar", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  date: timestamp("date").notNull(),
  dayType: dayTypeEnum("day_type").notNull(),
  name: text("name"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Orders
export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  locationId: varchar("location_id").notNull(),
  orderNumber: text("order_number").notNull(),
  clientId: varchar("client_id").notNull(),
  status: orderStatusEnum("status").notNull().default("DRAFT"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull().default("0"),
  discountPercent: integer("discount_percent").notNull().default(0),
  discountFixed: decimal("discount_fixed", { precision: 10, scale: 2 }).notNull().default("0"),
  total: decimal("total", { precision: 10, scale: 2 }).notNull().default("0"),
  notes: text("notes"),
  createdById: varchar("created_by_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Order bundle records (bundle rental entries for billing)
export const orderBundleRecords = pgTable("order_bundle_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: varchar("order_id").notNull(),
  bundleId: varchar("bundle_id").notNull(),
  category: categoryEnum("category").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  status: orderStatusEnum("status").notNull().default("OPEN"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Order bundle assignments (which physical items are assigned to bundle)
export const orderBundleAssignments = pgTable("order_bundle_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderBundleId: varchar("order_bundle_id").notNull(),
  equipmentItemId: varchar("equipment_item_id").notNull(),
  componentId: varchar("component_id").notNull(),
  returned: boolean("returned").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Order items (позиции заказа)
export const orderItems = pgTable("order_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: varchar("order_id").notNull(),
  equipmentTypeId: varchar("equipment_type_id"),
  equipmentItemId: varchar("equipment_item_id"),
  orderBundleId: varchar("order_bundle_id"),
  category: categoryEnum("category").notNull(),
  quantity: integer("quantity").notNull().default(1),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  isFree: boolean("is_free").notNull().default(false),
  freeReason: text("free_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Payments
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: varchar("order_id").notNull(),
  paymentType: paymentTypeEnum("payment_type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Discounts and promo codes
export const discounts = pgTable("discounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  percent: integer("percent").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  requiresTag: text("requires_tag"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Client Tag Definitions (customizable client categories)
export const clientTagDefinitions = pgTable("client_tag_definitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  color: text("color").notNull().default("gray"),
  icon: text("icon"),
  discountPercent: integer("discount_percent").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Workspace Settings (general system settings)
export const workspaceSettings = pgTable("workspace_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull().unique(),
  companyName: text("company_name").notNull().default("Прокат спортивного инвентаря"),
  currency: text("currency").notNull().default("₽"),
  timezone: text("timezone").notNull().default("Europe/Moscow"),
  dateFormat: text("date_format").notNull().default("dd.MM.yyyy"),
  timeFormat: text("time_format").notNull().default("HH:mm"),
  businessHoursStart: text("business_hours_start").notNull().default("09:00"),
  businessHoursEnd: text("business_hours_end").notNull().default("21:00"),
  defaultRentalDuration: integer("default_rental_duration").notNull().default(4),
  requireClientPhone: boolean("require_client_phone").notNull().default(true),
  allowNegativeInventory: boolean("allow_negative_inventory").notNull().default(false),
  autoCloseOrders: boolean("auto_close_orders").notNull().default(true),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [users.workspaceId],
    references: [workspaces.id],
  }),
  location: one(locations, {
    fields: [users.locationId],
    references: [locations.id],
  }),
}));

export const workspacesRelations = relations(workspaces, ({ many }) => ({
  users: many(users),
  locations: many(locations),
  clients: many(clients),
  equipmentTypes: many(equipmentTypes),
  orders: many(orders),
  discounts: many(discounts),
}));

export const locationsRelations = relations(locations, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [locations.workspaceId],
    references: [workspaces.id],
  }),
  equipmentItems: many(equipmentItems),
  orders: many(orders),
}));

export const clientsRelations = relations(clients, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [clients.workspaceId],
    references: [workspaces.id],
  }),
  orders: many(orders),
}));

export const equipmentTypesRelations = relations(equipmentTypes, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [equipmentTypes.workspaceId],
    references: [workspaces.id],
  }),
  items: many(equipmentItems),
  tariffs: many(tariffs),
  orderItems: many(orderItems),
  bundleComponents: many(bundleComponents),
}));

export const bundleDefinitionsRelations = relations(bundleDefinitions, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [bundleDefinitions.workspaceId],
    references: [workspaces.id],
  }),
  components: many(bundleComponents),
  tariffs: many(tariffs),
}));

export const bundleComponentsRelations = relations(bundleComponents, ({ one }) => ({
  bundle: one(bundleDefinitions, {
    fields: [bundleComponents.bundleId],
    references: [bundleDefinitions.id],
  }),
  equipmentType: one(equipmentTypes, {
    fields: [bundleComponents.equipmentTypeId],
    references: [equipmentTypes.id],
  }),
}));

export const equipmentItemsRelations = relations(equipmentItems, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [equipmentItems.workspaceId],
    references: [workspaces.id],
  }),
  location: one(locations, {
    fields: [equipmentItems.locationId],
    references: [locations.id],
  }),
  equipmentType: one(equipmentTypes, {
    fields: [equipmentItems.equipmentTypeId],
    references: [equipmentTypes.id],
  }),
  orderItems: many(orderItems),
}));

export const tariffsRelations = relations(tariffs, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [tariffs.workspaceId],
    references: [workspaces.id],
  }),
  equipmentType: one(equipmentTypes, {
    fields: [tariffs.equipmentTypeId],
    references: [equipmentTypes.id],
  }),
  bundle: one(bundleDefinitions, {
    fields: [tariffs.bundleId],
    references: [bundleDefinitions.id],
  }),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [orders.workspaceId],
    references: [workspaces.id],
  }),
  location: one(locations, {
    fields: [orders.locationId],
    references: [locations.id],
  }),
  client: one(clients, {
    fields: [orders.clientId],
    references: [clients.id],
  }),
  createdBy: one(users, {
    fields: [orders.createdById],
    references: [users.id],
  }),
  items: many(orderItems),
  payments: many(payments),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  equipmentType: one(equipmentTypes, {
    fields: [orderItems.equipmentTypeId],
    references: [equipmentTypes.id],
  }),
  equipmentItem: one(equipmentItems, {
    fields: [orderItems.equipmentItemId],
    references: [equipmentItems.id],
  }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  order: one(orders, {
    fields: [payments.orderId],
    references: [orders.id],
  }),
}));

export const discountsRelations = relations(discounts, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [discounts.workspaceId],
    references: [workspaces.id],
  }),
}));

export const clientTagDefinitionsRelations = relations(clientTagDefinitions, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [clientTagDefinitions.workspaceId],
    references: [workspaces.id],
  }),
}));

export const workspaceSettingsRelations = relations(workspaceSettings, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [workspaceSettings.workspaceId],
    references: [workspaces.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertWorkspaceSchema = createInsertSchema(workspaces).omit({
  id: true,
  createdAt: true,
});

export const insertLocationSchema = createInsertSchema(locations).omit({
  id: true,
  createdAt: true,
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true,
});

export const insertEquipmentTypeSchema = createInsertSchema(equipmentTypes).omit({
  id: true,
  createdAt: true,
});

export const insertBundleDefinitionSchema = createInsertSchema(bundleDefinitions).omit({
  id: true,
  createdAt: true,
});

export const insertBundleComponentSchema = createInsertSchema(bundleComponents).omit({
  id: true,
  createdAt: true,
});

export const insertEquipmentItemSchema = createInsertSchema(equipmentItems).omit({
  id: true,
  createdAt: true,
});

export const insertTariffSchema = createInsertSchema(tariffs).omit({
  id: true,
  createdAt: true,
});

export const insertCalendarSchema = createInsertSchema(calendar).omit({
  id: true,
  createdAt: true,
}).extend({
  date: z.coerce.date(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
  createdAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

export const insertDiscountSchema = createInsertSchema(discounts).omit({
  id: true,
  createdAt: true,
});

export const insertOrderBundleRecordSchema = createInsertSchema(orderBundleRecords).omit({
  id: true,
  createdAt: true,
});

export const insertOrderBundleAssignmentSchema = createInsertSchema(orderBundleAssignments).omit({
  id: true,
  createdAt: true,
});

export const insertClientTagDefinitionSchema = createInsertSchema(clientTagDefinitions).omit({
  id: true,
  createdAt: true,
});

export const insertWorkspaceSettingsSchema = createInsertSchema(workspaceSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// TypeScript types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Workspace = typeof workspaces.$inferSelect;
export type InsertWorkspace = z.infer<typeof insertWorkspaceSchema>;

export type Location = typeof locations.$inferSelect;
export type InsertLocation = z.infer<typeof insertLocationSchema>;

export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;

export type EquipmentType = typeof equipmentTypes.$inferSelect;
export type InsertEquipmentType = z.infer<typeof insertEquipmentTypeSchema>;

export type BundleDefinition = typeof bundleDefinitions.$inferSelect;
export type InsertBundleDefinition = z.infer<typeof insertBundleDefinitionSchema>;

export type BundleComponent = typeof bundleComponents.$inferSelect;
export type InsertBundleComponent = z.infer<typeof insertBundleComponentSchema>;

export type EquipmentItem = typeof equipmentItems.$inferSelect;
export type InsertEquipmentItem = z.infer<typeof insertEquipmentItemSchema>;

export type Tariff = typeof tariffs.$inferSelect;
export type InsertTariff = z.infer<typeof insertTariffSchema>;

export type Calendar = typeof calendar.$inferSelect;
export type InsertCalendar = z.infer<typeof insertCalendarSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type Discount = typeof discounts.$inferSelect;
export type InsertDiscount = z.infer<typeof insertDiscountSchema>;

export type OrderBundleRecord = typeof orderBundleRecords.$inferSelect;
export type InsertOrderBundleRecord = z.infer<typeof insertOrderBundleRecordSchema>;

export type OrderBundleAssignment = typeof orderBundleAssignments.$inferSelect;
export type InsertOrderBundleAssignment = z.infer<typeof insertOrderBundleAssignmentSchema>;

export type ClientTagDefinition = typeof clientTagDefinitions.$inferSelect;
export type InsertClientTagDefinition = z.infer<typeof insertClientTagDefinitionSchema>;

export type WorkspaceSettings = typeof workspaceSettings.$inferSelect;
export type InsertWorkspaceSettings = z.infer<typeof insertWorkspaceSettingsSchema>;
