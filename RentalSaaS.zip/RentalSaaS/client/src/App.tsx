import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import NewOrderPage from "@/pages/new-order-page";
import EditOrderPage from "@/pages/edit-order-page";
import ClientsPage from "@/pages/clients-page";
import InventoryPage from "@/pages/inventory-page";
import ReportsPage from "@/pages/reports-page";
import AdminTariffsPage from "@/pages/admin-tariffs-page";
import AdminCalendarPage from "@/pages/admin-calendar-page";
import AdminBundlesPage from "@/pages/admin-bundles-page";
import AdminSettingsPage from "@/pages/admin-settings-page";
import NotFound from "@/pages/not-found";
import AppLayout from "@/components/app-layout";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={() => <AppLayout><DashboardPage /></AppLayout>} />
      <ProtectedRoute path="/orders/new" component={() => <AppLayout><NewOrderPage /></AppLayout>} />
      <ProtectedRoute path="/orders/:id/edit" component={() => <AppLayout><EditOrderPage /></AppLayout>} />
      <ProtectedRoute path="/clients" component={() => <AppLayout><ClientsPage /></AppLayout>} />
      <ProtectedRoute path="/inventory" component={() => <AppLayout><InventoryPage /></AppLayout>} />
      <ProtectedRoute path="/reports" component={() => <AppLayout><ReportsPage /></AppLayout>} />
      <ProtectedRoute path="/admin/tariffs" component={() => <AppLayout><AdminTariffsPage /></AppLayout>} />
      <ProtectedRoute path="/admin/calendar" component={() => <AppLayout><AdminCalendarPage /></AppLayout>} />
      <ProtectedRoute path="/admin/bundles" component={() => <AppLayout><AdminBundlesPage /></AppLayout>} />
      <ProtectedRoute path="/admin/settings" component={() => <AppLayout><AdminSettingsPage /></AppLayout>} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
