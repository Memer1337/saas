import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, TrendingUp, DollarSign, Package, Users } from "lucide-react";
import { Order, Client } from "@shared/schema";

export default function ReportsPage() {
  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const { data: clients, isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  if (ordersLoading || clientsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const totalRevenue = orders
    ?.filter(o => o.status === "PAID" || o.status === "CLOSED")
    .reduce((sum, o) => sum + parseFloat(o.total), 0) || 0;

  const totalOrders = orders?.length || 0;
  const paidOrders = orders?.filter(o => o.status === "PAID" || o.status === "CLOSED") || [];
  const averageCheck = paidOrders.length > 0 ? totalRevenue / paidOrders.length : 0;

  const totalDiscounts = orders?.reduce(
    (sum, o) => sum + (parseFloat(o.subtotal) - parseFloat(o.total)),
    0
  ) || 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Отчёты</h1>
            <p className="text-muted-foreground mt-1">
              Статистика и аналитика
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Общая выручка
              </CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono text-foreground">
                {totalRevenue.toLocaleString("ru-RU")} ₽
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {paidOrders.length} оплаченных заказов
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Средний чек
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono text-foreground">
                {averageCheck.toLocaleString("ru-RU")} ₽
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                В среднем на заказ
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Всего заказов
              </CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {totalOrders}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                За всё время
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Всего скидок
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono text-foreground">
                {totalDiscounts.toLocaleString("ru-RU")} ₽
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Предоставлено клиентам
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Reports */}
        <Card>
          <CardHeader>
            <CardTitle>Детальная статистика</CardTitle>
            <CardDescription>
              Подробная информация о работе точки проката
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-sm text-muted-foreground">Количество клиентов в базе</span>
                <span className="text-lg font-semibold text-foreground">{clients?.length || 0}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-sm text-muted-foreground">Открытые заказы</span>
                <span className="text-lg font-semibold text-foreground">
                  {orders?.filter(o => o.status === "OPEN").length || 0}
                </span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-sm text-muted-foreground">Черновики</span>
                <span className="text-lg font-semibold text-foreground">
                  {orders?.filter(o => o.status === "DRAFT").length || 0}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Закрытые заказы</span>
                <span className="text-lg font-semibold text-foreground">
                  {orders?.filter(o => o.status === "CLOSED").length || 0}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
