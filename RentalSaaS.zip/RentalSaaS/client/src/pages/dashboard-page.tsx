import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, DollarSign, Package, Users, TrendingUp, Loader2, Check, X, Pencil } from "lucide-react";
import { Link } from "wouter";
import { Order, Client, OrderItem, EquipmentType } from "@shared/schema";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface OrderRowProps {
  order: Order;
  client: Client | undefined;
  orderItems: OrderItem[];
  equipmentTypes: EquipmentType[];
}

function OrderRow({ order, client, orderItems, equipmentTypes }: OrderRowProps) {
  const [startTime, setStartTime] = useState<string>(new Date(order.startTime).toISOString());
  const [endTime, setEndTime] = useState<string>(new Date(order.endTime).toISOString());
  const [selectedItems, setSelectedItems] = useState<Array<{ equipmentTypeId: string; category: string; quantity: number }>>([]);
  const [equipmentDialogOpen, setEquipmentDialogOpen] = useState(false);
  const [calculatedPrice, setCalculatedPrice] = useState(order.total);
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [barcodeInput, setBarcodeInput] = useState("");
  const { toast } = useToast();

  const { data: tariffs } = useQuery<any[]>({
    queryKey: ["/api/tariffs"],
  });

  const { data: equipmentItems } = useQuery<any[]>({
    queryKey: ["/api/equipment-items"],
  });

  // Sync selectedItems with orderItems when they arrive, but only if not currently editing
  useEffect(() => {
    // Skip sync if user has unsaved changes to avoid overwriting their edits
    if (hasChanges) return;
    
    setSelectedItems(orderItems.map(item => ({
      equipmentTypeId: item.equipmentTypeId || "",
      category: item.category,
      quantity: item.quantity
    })));
  }, [orderItems, hasChanges]);

  // Check for changes
  useEffect(() => {
    const timeChanged = startTime !== new Date(order.startTime).toISOString() || 
                        endTime !== new Date(order.endTime).toISOString();
    const itemsChanged = JSON.stringify(selectedItems) !== JSON.stringify(orderItems.map(i => ({
      equipmentTypeId: i.equipmentTypeId || "",
      category: i.category,
      quantity: i.quantity
    })));
    setHasChanges(timeChanged || itemsChanged);
  }, [startTime, endTime, selectedItems, order, orderItems]);

  // Calculate price whenever times or items change
  useEffect(() => {
    if (!tariffs) return;

    const start = new Date(startTime);
    const end = new Date(endTime);
    const minutes = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60));
    const dayType = start.getDay() === 0 || start.getDay() === 6 ? "WEEKEND" : "WEEKDAY";

    let subtotal = 0;
    for (const item of selectedItems) {
      const tariff = tariffs.find(t =>
        t.equipmentTypeId === item.equipmentTypeId &&
        t.category === item.category &&
        t.dayType === dayType
      );

      if (tariff) {
        const basePrice = parseFloat(tariff.basePrice);
        const incrementPrice = parseFloat(tariff.incrementPrice);
        const baseMinutes = tariff.baseHours * 60;
        
        let itemPrice = basePrice;
        const additionalMinutes = Math.max(0, minutes - baseMinutes);
        const increments = Math.ceil(additionalMinutes / tariff.incrementMinutes);
        itemPrice += increments * incrementPrice;
        itemPrice *= item.quantity;
        
        subtotal += itemPrice;
      }
    }

    const discount = order.discountPercent ? (subtotal * (order.discountPercent / 100)) : 0;
    const total = subtotal - discount;
    setCalculatedPrice(total.toString());
  }, [startTime, endTime, selectedItems, tariffs, order.discountPercent]);

  const updateMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("PATCH", `/api/orders/${order.id}`, {
        startTime: new Date(startTime).toISOString(),
        endTime: new Date(endTime).toISOString(),
        clientId: order.clientId,
        items: selectedItems,
        discountPercent: order.discountPercent,
      });
    },
    onSettled: () => {
      setIsSaving(false);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/order-items"] });
      
      // Check if there are new unsaved changes made during the save
      const currentChanges = 
        startTime !== new Date(order.startTime).toISOString() || 
        endTime !== new Date(order.endTime).toISOString() ||
        JSON.stringify(selectedItems) !== JSON.stringify(orderItems.map(i => ({
          equipmentTypeId: i.equipmentTypeId || "",
          category: i.category,
          quantity: i.quantity
        })));
      
      if (!currentChanges) {
        setHasChanges(false);
        toast({ title: "Сохранено", description: "Заказ автоматически обновлён" });
      }
      // If there are still changes, hasChanges will remain true and trigger another save
    },
    onError: (error: Error) => {
      toast({ 
        title: "Ошибка", 
        description: error.message,
        variant: "destructive"
      });
    },
  });

  // Auto-save with debounce
  useEffect(() => {
    if (!hasChanges || updateMutation.isPending) return;
    
    const timer = setTimeout(() => {
      setIsSaving(true);
      updateMutation.mutate();
    }, 2000);

    return () => clearTimeout(timer);
  }, [hasChanges, startTime, endTime, selectedItems, updateMutation.isPending]);

  const handleReset = () => {
    setStartTime(new Date(order.startTime).toISOString());
    setEndTime(new Date(order.endTime).toISOString());
    setSelectedItems(orderItems.map(item => ({
      equipmentTypeId: item.equipmentTypeId || "",
      category: item.category,
      quantity: item.quantity
    })));
    setCalculatedPrice(order.total);
    setHasChanges(false);
  };

  const toggleEquipmentItem = (typeId: string, category: "ADULT" | "CHILD") => {
    const exists = selectedItems.find(i => i.equipmentTypeId === typeId && i.category === category);
    if (exists) {
      setSelectedItems(selectedItems.filter(i => !(i.equipmentTypeId === typeId && i.category === category)));
    } else {
      setSelectedItems([...selectedItems, { equipmentTypeId: typeId, category, quantity: 1 }]);
    }
  };

  const handleAddByBarcode = () => {
    if (!barcodeInput.trim()) {
      toast({ 
        title: "Ошибка", 
        description: "Введите штрихкод",
        variant: "destructive"
      });
      return;
    }

    if (!equipmentItems) {
      toast({ 
        title: "Загрузка", 
        description: "Пожалуйста, подождите, загружается список оборудования",
      });
      return;
    }

    const item = equipmentItems?.find(i => i.barcode === barcodeInput.trim());
    if (!item) {
      toast({ 
        title: "Не найдено", 
        description: `Оборудование со штрихкодом ${barcodeInput} не найдено`,
        variant: "destructive"
      });
      return;
    }

    // Add equipment as ADULT category by default
    const exists = selectedItems.find(i => 
      i.equipmentTypeId === item.equipmentTypeId && i.category === "ADULT"
    );
    
    if (exists) {
      toast({ 
        title: "Уже добавлено", 
        description: "Это оборудование уже есть в списке",
      });
    } else {
      setSelectedItems([...selectedItems, { 
        equipmentTypeId: item.equipmentTypeId, 
        category: "ADULT", 
        quantity: 1 
      }]);
      toast({ 
        title: "Добавлено", 
        description: "Оборудование добавлено в заказ",
      });
    }
    
    setBarcodeInput("");
  };

  const formatEquipmentList = () => {
    return selectedItems.map(item => {
      const type = equipmentTypes.find(t => t.id === item.equipmentTypeId);
      const catLabel = item.category === "ADULT" ? "взр" : "дет";
      return `${type?.name || "?"} (${catLabel})${item.quantity > 1 ? ` x${item.quantity}` : ""}`;
    }).join(", ");
  };

  return (
    <tr
      className="border-b border-border hover-elevate"
      data-testid={`row-order-${order.id}`}
    >
      <td className="py-3 px-4 text-sm text-foreground">
        {client?.fullName || "—"}
      </td>
      <td className="py-3 px-4 text-sm text-muted-foreground">
        {client?.phone || "—"}
      </td>
      <td className="py-3 px-4">
        <Dialog open={equipmentDialogOpen} onOpenChange={setEquipmentDialogOpen}>
          <DialogTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="w-full max-w-xs text-left justify-start"
              data-testid={`button-equipment-${order.id}`}
            >
              <span className="truncate">{formatEquipmentList() || "Выбрать..."}</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Выбор оборудования</DialogTitle>
            </DialogHeader>
            
            {/* Barcode input section */}
            <div className="border-b border-border pb-4 mb-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="Введите или отсканируйте штрихкод..."
                    value={barcodeInput}
                    onChange={(e) => setBarcodeInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleAddByBarcode();
                      }
                    }}
                    data-testid={`input-barcode-${order.id}`}
                  />
                </div>
                <Button 
                  onClick={handleAddByBarcode}
                  data-testid={`button-add-by-barcode-${order.id}`}
                >
                  Добавить по штрих-коду
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Добавляет оборудование в категории "Взрослый"
              </p>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto">
              {equipmentTypes.map(type => (
                <div key={type.id} className="space-y-2">
                  <div className="font-semibold text-sm">{type.name}</div>
                  <div className="flex gap-4 pl-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox
                        checked={selectedItems.some(i => i.equipmentTypeId === type.id && i.category === "ADULT")}
                        onCheckedChange={() => toggleEquipmentItem(type.id, "ADULT")}
                        data-testid={`checkbox-${type.id}-adult`}
                      />
                      <span className="text-sm">Взрослый</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox
                        checked={selectedItems.some(i => i.equipmentTypeId === type.id && i.category === "CHILD")}
                        onCheckedChange={() => toggleEquipmentItem(type.id, "CHILD")}
                        data-testid={`checkbox-${type.id}-child`}
                      />
                      <span className="text-sm">Детский</span>
                    </label>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button onClick={() => setEquipmentDialogOpen(false)}>
                Готово
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </td>
      <td className="py-3 px-4">
        <Input
          type="datetime-local"
          value={format(new Date(startTime), "yyyy-MM-dd'T'HH:mm")}
          onChange={(e) => {
            if (e.target.value) {
              const date = new Date(e.target.value);
              if (!isNaN(date.getTime())) {
                setStartTime(date.toISOString());
              }
            }
          }}
          className="w-40"
          data-testid={`input-start-time-${order.id}`}
        />
      </td>
      <td className="py-3 px-4">
        <Input
          type="datetime-local"
          value={format(new Date(endTime), "yyyy-MM-dd'T'HH:mm")}
          onChange={(e) => {
            if (e.target.value) {
              const date = new Date(e.target.value);
              if (!isNaN(date.getTime())) {
                setEndTime(date.toISOString());
              }
            }
          }}
          className="w-40"
          data-testid={`input-end-time-${order.id}`}
        />
      </td>
      <td className="py-3 px-4 text-right">
        <span className="font-mono font-semibold text-primary">
          {parseFloat(calculatedPrice).toLocaleString("ru-RU")} ₽
        </span>
      </td>
      <td className="py-3 px-4 text-center">
        <div className="flex items-center justify-center gap-2">
          {isSaving || updateMutation.isPending ? (
            <div className="flex items-center gap-2 text-muted-foreground text-xs" data-testid={`status-saving-${order.id}`}>
              <Loader2 className="h-3 w-3 animate-spin" />
              <span>Сохранение...</span>
            </div>
          ) : hasChanges ? (
            <div className="flex items-center gap-2 text-muted-foreground text-xs" data-testid={`status-unsaved-${order.id}`}>
              <span>Несохранённые изменения</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-green-600 text-xs" data-testid={`status-saved-${order.id}`}>
              <Check className="h-3 w-3" />
              <span>Сохранено</span>
            </div>
          )}
        </div>
      </td>
    </tr>
  );
}

export default function DashboardPage() {
  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const { data: clients, isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  const { data: equipmentTypes } = useQuery<EquipmentType[]>({
    queryKey: ["/api/equipment-types"],
  });

  // Fetch order items for all orders
  const orderIds = orders?.map(o => o.id) || [];
  const { data: allOrderItems } = useQuery<OrderItem[]>({
    queryKey: ["/api/order-items", "all"],
    queryFn: async () => {
      const results = await Promise.all(
        orderIds.map(async (orderId) => {
          const res = await fetch(`/api/order-items?orderId=${orderId}`, {
            credentials: "include",
          });
          if (!res.ok) throw new Error("Failed to fetch order items");
          return res.json();
        })
      );
      return results.flat();
    },
    enabled: orderIds.length > 0,
  });

  const activeOrders = orders?.filter(o => o.status === "OPEN" || o.status === "DRAFT") || [];
  const paidOrders = orders?.filter(o => o.status === "PAID") || [];
  
  const totalRevenue = orders
    ?.filter(o => o.status === "PAID" || o.status === "CLOSED")
    .reduce((sum, o) => sum + parseFloat(o.total), 0) || 0;

  const averageCheck = paidOrders.length > 0 
    ? totalRevenue / paidOrders.length 
    : 0;

  if (ordersLoading || clientsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Главная</h1>
              <p className="text-muted-foreground mt-1">
                {format(new Date(), "d MMMM yyyy", { locale: ru })}
              </p>
            </div>
            <Link href="/orders/new">
              <Button size="lg" data-testid="button-new-order">
                <Plus className="mr-2 h-5 w-5" />
                Новый заказ
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Выручка
              </CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono text-foreground">
                {totalRevenue.toLocaleString("ru-RU")} ₽
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                За всё время
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Средний чек
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono text-foreground">
                {averageCheck.toLocaleString("ru-RU")} ₽
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {paidOrders.length} оплаченных
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Активные заказы
              </CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {activeOrders.length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Сейчас в работе
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Клиенты
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {clients?.length || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                В базе
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Active Orders Table */}
        <Card>
          <CardHeader>
            <CardTitle>Активные заказы</CardTitle>
            <CardDescription>
              Заказы в работе и требующие внимания
            </CardDescription>
          </CardHeader>
          <CardContent>
            {activeOrders.length === 0 ? (
              <div className="text-center py-12">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Нет активных заказов</p>
                <Link href="/orders/new">
                  <Button variant="outline" className="mt-4" data-testid="button-create-first-order">
                    Создать первый заказ
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                        ФИО клиента
                      </th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                        Телефон
                      </th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                        Что взял
                      </th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                        Время взял
                      </th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                        Время сдал
                      </th>
                      <th className="text-right py-3 px-4 text-sm font-semibold text-foreground">
                        Цена
                      </th>
                      <th className="text-center py-3 px-4 text-sm font-semibold text-foreground">
                        Статус
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {activeOrders.map((order) => {
                      const client = clients?.find(c => c.id === order.clientId);
                      const orderItems = allOrderItems?.filter(i => i.orderId === order.id) || [];
                      return (
                        <OrderRow
                          key={order.id}
                          order={order}
                          client={client}
                          orderItems={orderItems}
                          equipmentTypes={equipmentTypes || []}
                        />
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
