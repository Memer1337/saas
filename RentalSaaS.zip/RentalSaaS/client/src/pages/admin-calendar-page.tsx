import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Calendar as CalendarIcon, Loader2, Trash2, Plus } from "lucide-react";
import { Calendar } from "@shared/schema";
import { format, isSameDay } from "date-fns";
import { ru } from "date-fns/locale";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AdminCalendarPage() {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDay, setEditingDay] = useState<Calendar | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    dayType: "HOLIDAY" as "WEEKDAY" | "WEEKEND" | "HOLIDAY",
  });

  const { data: calendar, isLoading } = useQuery<Calendar[]>({
    queryKey: ["/api/calendar"],
  });

  const createCalendarDayMutation = useMutation({
    mutationFn: async (data: { date: string; name: string; dayType: string }) => {
      const res = await apiRequest("POST", "/api/calendar", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Успешно",
        description: "Особый день добавлен",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/calendar"] });
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateCalendarDayMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: { name: string; dayType: string } }) => {
      const res = await apiRequest("PATCH", `/api/calendar/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Успешно",
        description: "Особый день обновлён",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/calendar"] });
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteCalendarDayMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/calendar/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Удалено",
        description: "Особый день удалён",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/calendar"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setIsDialogOpen(false);
    setEditingDay(null);
    setFormData({
      name: "",
      dayType: "HOLIDAY",
    });
  };

  const handleDateSelect = (date: Date | undefined) => {
    if (!date) return;
    setSelectedDate(date);
    
    // Check if this date already has a special day
    const existingDay = calendar?.find(day => 
      isSameDay(new Date(day.date), date)
    );
    
    if (existingDay) {
      // Open dialog for editing
      setEditingDay(existingDay);
      setFormData({
        name: existingDay.name || "",
        dayType: existingDay.dayType,
      });
      setIsDialogOpen(true);
    } else {
      // Open dialog for new day
      setEditingDay(null);
      setFormData({
        name: "",
        dayType: "HOLIDAY",
      });
      setIsDialogOpen(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingDay) {
      // Update existing day
      updateCalendarDayMutation.mutate({
        id: editingDay.id,
        data: {
          name: formData.name,
          dayType: formData.dayType,
        },
      });
    } else {
      // Create new day
      if (!selectedDate) return;
      createCalendarDayMutation.mutate({
        date: selectedDate.toISOString(),
        name: formData.name,
        dayType: formData.dayType,
      });
    }
  };

  const handleDelete = (id: string) => {
    if (confirm("Вы уверены, что хотите удалить этот день?")) {
      deleteCalendarDayMutation.mutate(id);
    }
  };

  const getDayTypeBadge = (dayType: string) => {
    const variants: Record<string, { label: string; className: string }> = {
      WEEKDAY: { label: "Будний", className: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" },
      WEEKEND: { label: "Выходной", className: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200" },
      HOLIDAY: { label: "Праздник", className: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200" },
    };
    const config = variants[dayType] || variants.HOLIDAY;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  // Get dates that have special days
  const modifiers = {
    holiday: calendar?.filter(day => day.dayType === "HOLIDAY").map(day => new Date(day.date)) || [],
    weekend: calendar?.filter(day => day.dayType === "WEEKEND").map(day => new Date(day.date)) || [],
    weekday: calendar?.filter(day => day.dayType === "WEEKDAY").map(day => new Date(day.date)) || [],
  };

  const modifiersClassNames = {
    holiday: "bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-100 font-bold",
    weekend: "bg-purple-200 dark:bg-purple-900 text-purple-900 dark:text-purple-100 font-bold",
    weekday: "bg-blue-200 dark:bg-blue-900 text-blue-900 dark:text-blue-100 font-bold",
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Dialog for creating/editing special day */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingDay ? "Редактировать особый день" : "Добавить особый день"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Дата</Label>
              <div className="text-sm font-medium">
                {selectedDate && format(selectedDate, "d MMMM yyyy", { locale: ru })}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Название</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Новый год"
                data-testid="input-day-name"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dayType">Тип дня</Label>
              <Select
                value={formData.dayType}
                onValueChange={(value: "WEEKDAY" | "WEEKEND" | "HOLIDAY") =>
                  setFormData({ ...formData, dayType: value })
                }
              >
                <SelectTrigger data-testid="select-day-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="HOLIDAY">Праздник</SelectItem>
                  <SelectItem value="WEEKEND">Выходной</SelectItem>
                  <SelectItem value="WEEKDAY">Будний</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={resetForm}
              >
                Отмена
              </Button>
              <Button
                type="submit"
                disabled={createCalendarDayMutation.isPending || updateCalendarDayMutation.isPending}
                data-testid="button-submit-day"
              >
                {(createCalendarDayMutation.isPending || updateCalendarDayMutation.isPending) && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                {editingDay ? "Сохранить" : "Добавить"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 md:py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">Календарь</h1>
              <p className="text-muted-foreground mt-1 text-sm md:text-base">
                Управление праздниками и особыми днями
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 md:py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Calendar */}
          <Card>
            <CardHeader>
              <CardTitle>Выберите дату</CardTitle>
              <CardDescription>
                Кликните на день чтобы добавить особый день
              </CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <CalendarComponent
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                modifiers={modifiers}
                modifiersClassNames={modifiersClassNames}
                locale={ru}
                className="rounded-md border"
                data-testid="calendar-picker"
              />
            </CardContent>
          </Card>

          {/* Special Days List */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Особые дни</CardTitle>
                  <CardDescription>
                    Праздники и дни с особыми тарифами
                  </CardDescription>
                </div>
                <Button
                  onClick={() => setIsDialogOpen(true)}
                  size="sm"
                  data-testid="button-add-day"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Добавить
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {!calendar || calendar.length === 0 ? (
                <div className="text-center py-12">
                  <CalendarIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground text-sm">Нет особых дней в календаре</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {calendar.map((day) => (
                    <div
                      key={day.id}
                      className="flex items-center justify-between p-3 rounded-md border border-border hover-elevate"
                      data-testid={`day-item-${day.id}`}
                    >
                      <div className="flex-1">
                        <div className="font-mono text-sm font-medium text-foreground">
                          {format(new Date(day.date), "d MMMM yyyy", { locale: ru })}
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">
                          {day.name || "-"}
                        </div>
                        <div className="mt-2">
                          {getDayTypeBadge(day.dayType)}
                        </div>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleDelete(day.id)}
                        data-testid={`button-delete-day-${day.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Legend */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-lg">Обозначения</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-amber-200 dark:bg-amber-900 border"></div>
                <span className="text-sm">Праздник</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-purple-200 dark:bg-purple-900 border"></div>
                <span className="text-sm">Выходной</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-blue-200 dark:bg-blue-900 border"></div>
                <span className="text-sm">Будний</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
