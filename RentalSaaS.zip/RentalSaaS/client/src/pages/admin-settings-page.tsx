import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Plus, Edit, Trash2, Settings, Tag, Package, Building2, Loader2 } from "lucide-react";
import type { ClientTagDefinition, EquipmentType, WorkspaceSettings } from "@shared/schema";

const COLORS = [
  { value: "gray", label: "Серый", className: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200" },
  { value: "blue", label: "Синий", className: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" },
  { value: "purple", label: "Фиолетовый", className: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200" },
  { value: "green", label: "Зелёный", className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" },
  { value: "amber", label: "Янтарный", className: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200" },
  { value: "red", label: "Красный", className: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200" },
  { value: "pink", label: "Розовый", className: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200" },
  { value: "indigo", label: "Индиго", className: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200" },
];

const TIMEZONES = [
  { value: "Europe/Kaliningrad", label: "(UTC+2) Калининград" },
  { value: "Europe/Moscow", label: "(UTC+3) Москва, Санкт-Петербург" },
  { value: "Europe/Samara", label: "(UTC+4) Самара, Ижевск" },
  { value: "Asia/Yekaterinburg", label: "(UTC+5) Екатеринбург" },
  { value: "Asia/Omsk", label: "(UTC+6) Омск" },
  { value: "Asia/Krasnoyarsk", label: "(UTC+7) Красноярск, Новосибирск" },
  { value: "Asia/Irkutsk", label: "(UTC+8) Иркутск" },
  { value: "Asia/Yakutsk", label: "(UTC+9) Якутск" },
  { value: "Asia/Vladivostok", label: "(UTC+10) Владивосток" },
  { value: "Asia/Magadan", label: "(UTC+11) Магадан" },
  { value: "Asia/Kamchatka", label: "(UTC+12) Камчатка" },
];

export default function AdminSettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("tags");

  // Client Tags state
  const [isTagDialogOpen, setIsTagDialogOpen] = useState(false);
  const [editingTag, setEditingTag] = useState<ClientTagDefinition | null>(null);
  const [tagFormData, setTagFormData] = useState({
    code: "",
    name: "",
    color: "gray",
    discountPercent: 0,
    isActive: true,
    sortOrder: 0,
  });

  const { data: clientTags, isLoading: tagsLoading } = useQuery<ClientTagDefinition[]>({
    queryKey: ["/api/client-tags"],
  });

  const { data: equipmentTypes, isLoading: typesLoading } = useQuery<EquipmentType[]>({
    queryKey: ["/api/equipment-types"],
  });

  const { data: workspaceSettings, isLoading: settingsLoading } = useQuery<WorkspaceSettings>({
    queryKey: ["/api/workspace-settings"],
  });

  // Workspace settings state
  const [settingsFormData, setSettingsFormData] = useState({
    companyName: "",
    currency: "₽",
    timezone: "Europe/Moscow",
    dateFormat: "dd.MM.yyyy",
    timeFormat: "HH:mm",
    businessHoursStart: "09:00",
    businessHoursEnd: "21:00",
    defaultRentalDuration: 4,
  });

  // Update form when settings load
  useEffect(() => {
    if (workspaceSettings) {
      setSettingsFormData({
        companyName: workspaceSettings.companyName,
        currency: workspaceSettings.currency,
        timezone: workspaceSettings.timezone,
        dateFormat: workspaceSettings.dateFormat,
        timeFormat: workspaceSettings.timeFormat,
        businessHoursStart: workspaceSettings.businessHoursStart,
        businessHoursEnd: workspaceSettings.businessHoursEnd,
        defaultRentalDuration: workspaceSettings.defaultRentalDuration,
      });
    }
  }, [workspaceSettings]);

  // Client Tag mutations
  const createTagMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/client-tags", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Создано", description: "Категория клиентов успешно добавлена" });
      queryClient.invalidateQueries({ queryKey: ["/api/client-tags"] });
      resetTagForm();
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const updateTagMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("PATCH", `/api/client-tags/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Сохранено", description: "Категория клиентов обновлена" });
      queryClient.invalidateQueries({ queryKey: ["/api/client-tags"] });
      resetTagForm();
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const deleteTagMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/client-tags/${id}`);
    },
    onSuccess: () => {
      toast({ title: "Удалено", description: "Категория клиентов удалена" });
      queryClient.invalidateQueries({ queryKey: ["/api/client-tags"] });
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  // Workspace settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PUT", "/api/workspace-settings", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Сохранено", description: "Настройки workspace успешно обновлены" });
      queryClient.invalidateQueries({ queryKey: ["/api/workspace-settings"] });
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const resetTagForm = () => {
    setIsTagDialogOpen(false);
    setEditingTag(null);
    setTagFormData({
      code: "",
      name: "",
      color: "gray",
      discountPercent: 0,
      isActive: true,
      sortOrder: 0,
    });
  };

  const openTagDialog = (tag?: ClientTagDefinition) => {
    if (tag) {
      setEditingTag(tag);
      setTagFormData({
        code: tag.code,
        name: tag.name,
        color: tag.color,
        discountPercent: tag.discountPercent,
        isActive: tag.isActive,
        sortOrder: tag.sortOrder,
      });
    } else {
      resetTagForm();
    }
    setIsTagDialogOpen(true);
  };

  const handleTagSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingTag) {
      updateTagMutation.mutate({ id: editingTag.id, data: tagFormData });
    } else {
      createTagMutation.mutate(tagFormData);
    }
  };

  const handleDeleteTag = (id: string, name: string) => {
    if (confirm(`Вы уверены, что хотите удалить категорию "${name}"?`)) {
      deleteTagMutation.mutate(id);
    }
  };

  const getColorBadgeClass = (color: string) => {
    return COLORS.find(c => c.value === color)?.className || COLORS[0].className;
  };

  const handleSettingsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettingsMutation.mutate(settingsFormData);
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Настройки системы</h1>
        <p className="text-muted-foreground">
          Управление категориями клиентов, типами оборудования и общими настройками
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="tags" data-testid="tab-client-tags">
            <Tag className="w-4 h-4 mr-2" />
            Категории клиентов
          </TabsTrigger>
          <TabsTrigger value="equipment" data-testid="tab-equipment-types">
            <Package className="w-4 h-4 mr-2" />
            Типы оборудования
          </TabsTrigger>
          <TabsTrigger value="general" data-testid="tab-general-settings">
            <Building2 className="w-4 h-4 mr-2" />
            Общие настройки
          </TabsTrigger>
        </TabsList>

        {/* Client Tags Tab */}
        <TabsContent value="tags" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Категории клиентов</CardTitle>
                  <CardDescription>
                    Настройка тегов клиентов для применения скидок и группировки
                  </CardDescription>
                </div>
                <Button onClick={() => openTagDialog()} data-testid="button-add-client-tag">
                  <Plus className="w-4 h-4 mr-2" />
                  Добавить категорию
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {tagsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : (
                <div className="space-y-2">
                  {clientTags && clientTags.length > 0 ? (
                    clientTags.map((tag) => (
                      <div
                        key={tag.id}
                        className="flex items-center justify-between p-4 border rounded-lg hover-elevate"
                        data-testid={`tag-item-${tag.code}`}
                      >
                        <div className="flex items-center gap-4">
                          <Badge className={getColorBadgeClass(tag.color)}>{tag.name}</Badge>
                          <span className="text-sm text-muted-foreground">Код: {tag.code}</span>
                          <span className="text-sm font-medium">Скидка: {tag.discountPercent}%</span>
                          {!tag.isActive && (
                            <Badge variant="outline" className="text-muted-foreground">
                              Неактивен
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openTagDialog(tag)}
                            data-testid={`button-edit-tag-${tag.code}`}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteTag(tag.id, tag.name)}
                            data-testid={`button-delete-tag-${tag.code}`}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      Категории клиентов не найдены. Добавьте первую категорию.
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Equipment Types Tab - Placeholder */}
        <TabsContent value="equipment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Типы оборудования</CardTitle>
              <CardDescription>
                Управление типами оборудования для проката
              </CardDescription>
            </CardHeader>
            <CardContent>
              {typesLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : (
                <div className="space-y-2">
                  {equipmentTypes && equipmentTypes.map((type) => (
                    <div
                      key={type.id}
                      className="flex items-center justify-between p-4 border rounded-lg"
                      data-testid={`equipment-type-${type.id}`}
                    >
                      <div className="flex items-center gap-4">
                        <span className="font-medium">{type.name}</span>
                        <Badge variant="outline">{type.rentalMode}</Badge>
                        {type.isBundle && <Badge variant="outline">Комплект</Badge>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* General Settings Tab */}
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Общие настройки</CardTitle>
              <CardDescription>
                Настройки workspace и параметры системы
              </CardDescription>
            </CardHeader>
            <CardContent>
              {settingsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : (
                <form onSubmit={handleSettingsSubmit} className="space-y-6">
                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="companyName">Название компании</Label>
                      <Input
                        id="companyName"
                        value={settingsFormData.companyName}
                        onChange={(e) => setSettingsFormData({ ...settingsFormData, companyName: e.target.value })}
                        placeholder="Прокат спортивного инвентаря"
                        data-testid="input-company-name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="timezone">Часовой пояс</Label>
                      <Select
                        value={settingsFormData.timezone}
                        onValueChange={(value) => setSettingsFormData({ ...settingsFormData, timezone: value })}
                      >
                        <SelectTrigger id="timezone" data-testid="select-timezone">
                          <SelectValue placeholder="Выберите часовой пояс" />
                        </SelectTrigger>
                        <SelectContent>
                          {TIMEZONES.map((tz) => (
                            <SelectItem key={tz.value} value={tz.value}>
                              {tz.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="currency">Валюта</Label>
                      <Input
                        id="currency"
                        value={settingsFormData.currency}
                        onChange={(e) => setSettingsFormData({ ...settingsFormData, currency: e.target.value })}
                        placeholder="₽"
                        data-testid="input-currency"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="defaultRentalDuration">Длительность аренды по умолчанию (часы)</Label>
                      <Input
                        id="defaultRentalDuration"
                        type="number"
                        min="1"
                        max="24"
                        value={settingsFormData.defaultRentalDuration}
                        onChange={(e) => setSettingsFormData({ ...settingsFormData, defaultRentalDuration: parseInt(e.target.value) })}
                        data-testid="input-default-rental-duration"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="businessHoursStart">Начало рабочего дня</Label>
                      <Input
                        id="businessHoursStart"
                        type="time"
                        value={settingsFormData.businessHoursStart}
                        onChange={(e) => setSettingsFormData({ ...settingsFormData, businessHoursStart: e.target.value })}
                        data-testid="input-business-hours-start"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="businessHoursEnd">Конец рабочего дня</Label>
                      <Input
                        id="businessHoursEnd"
                        type="time"
                        value={settingsFormData.businessHoursEnd}
                        onChange={(e) => setSettingsFormData({ ...settingsFormData, businessHoursEnd: e.target.value })}
                        data-testid="input-business-hours-end"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={updateSettingsMutation.isPending}
                      data-testid="button-save-settings"
                    >
                      {updateSettingsMutation.isPending && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Сохранить настройки
                    </Button>
                  </div>
                </form>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Client Tag Dialog */}
      <Dialog open={isTagDialogOpen} onOpenChange={setIsTagDialogOpen}>
        <DialogContent data-testid="dialog-client-tag">
          <DialogHeader>
            <DialogTitle>
              {editingTag ? "Редактировать категорию" : "Новая категория клиентов"}
            </DialogTitle>
            <DialogDescription>
              Задайте название, код, цвет и скидку для категории клиентов
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleTagSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="tag-code">Код категории</Label>
              <Input
                id="tag-code"
                value={tagFormData.code}
                onChange={(e) => setTagFormData({ ...tagFormData, code: e.target.value.toUpperCase() })}
                placeholder="STUDENT"
                required
                data-testid="input-tag-code"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tag-name">Название</Label>
              <Input
                id="tag-name"
                value={tagFormData.name}
                onChange={(e) => setTagFormData({ ...tagFormData, name: e.target.value })}
                placeholder="Студент"
                required
                data-testid="input-tag-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tag-color">Цвет</Label>
              <Select
                value={tagFormData.color}
                onValueChange={(value) => setTagFormData({ ...tagFormData, color: value })}
              >
                <SelectTrigger data-testid="select-tag-color">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {COLORS.map((color) => (
                    <SelectItem key={color.value} value={color.value}>
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded ${color.className}`} />
                        {color.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="tag-discount">Скидка (%)</Label>
              <Input
                id="tag-discount"
                type="number"
                min="0"
                max="100"
                value={tagFormData.discountPercent}
                onChange={(e) => setTagFormData({ ...tagFormData, discountPercent: parseInt(e.target.value) || 0 })}
                data-testid="input-tag-discount"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="tag-active"
                checked={tagFormData.isActive}
                onCheckedChange={(checked) => setTagFormData({ ...tagFormData, isActive: checked })}
                data-testid="switch-tag-active"
              />
              <Label htmlFor="tag-active">Активна</Label>
            </div>
            <div className="space-y-2">
              <Label htmlFor="tag-sort">Порядок сортировки</Label>
              <Input
                id="tag-sort"
                type="number"
                value={tagFormData.sortOrder}
                onChange={(e) => setTagFormData({ ...tagFormData, sortOrder: parseInt(e.target.value) || 0 })}
                data-testid="input-tag-sort"
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetTagForm}>
                Отмена
              </Button>
              <Button
                type="submit"
                disabled={createTagMutation.isPending || updateTagMutation.isPending}
                data-testid="button-save-tag"
              >
                {(createTagMutation.isPending || updateTagMutation.isPending) && (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                )}
                {editingTag ? "Сохранить" : "Создать"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
