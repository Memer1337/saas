import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Loader2, Settings, Edit2, Check, X } from "lucide-react";
import { Tariff, EquipmentType } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

function TariffRow({ tariff }: { tariff: Tariff }) {
  const [isEditing, setIsEditing] = useState(false);
  const [basePrice, setBasePrice] = useState(tariff.basePrice);
  const [incrementPrice, setIncrementPrice] = useState(tariff.incrementPrice);
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: async (data: { basePrice: string; incrementPrice: string }) => {
      return await apiRequest("PATCH", `/api/tariffs/${tariff.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tariffs"] });
      setIsEditing(false);
      toast({ title: "Сохранено", description: "Тариф успешно обновлён" });
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const handleSave = () => {
    updateMutation.mutate({ basePrice, incrementPrice });
  };

  const handleCancel = () => {
    setBasePrice(tariff.basePrice);
    setIncrementPrice(tariff.incrementPrice);
    setIsEditing(false);
  };

  const getDayTypeBadge = (dayType: string) => {
    const variants: Record<string, { label: string; className: string }> = {
      WEEKDAY: { label: "Будни", className: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" },
      WEEKEND: { label: "Выходные", className: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200" },
      HOLIDAY: { label: "Праздники", className: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200" },
    };
    const config = variants[dayType] || variants.WEEKDAY;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const getCategoryBadge = (category: string) => {
    const variants: Record<string, { label: string; className: string }> = {
      ADULT: { label: "Взрослый", className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" },
      CHILD: { label: "Детский", className: "bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200" },
    };
    const config = variants[category] || variants.ADULT;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  return (
    <tr className="border-b border-border hover-elevate" data-testid={`row-tariff-${tariff.id}`}>
      <td className="py-3 px-4">{getDayTypeBadge(tariff.dayType)}</td>
      <td className="py-3 px-4">{getCategoryBadge(tariff.category)}</td>
      <td className="py-3 px-4 text-right">
        {isEditing ? (
          <Input
            type="number"
            value={basePrice}
            onChange={(e) => setBasePrice(e.target.value)}
            className="w-32 text-right"
            data-testid={`input-base-price-${tariff.id}`}
          />
        ) : (
          <span className="font-mono font-semibold text-foreground">
            {parseFloat(tariff.basePrice).toLocaleString("ru-RU")} ₽
          </span>
        )}
      </td>
      <td className="py-3 px-4 text-center text-sm text-muted-foreground">
        {tariff.baseHours} ч
      </td>
      <td className="py-3 px-4 text-right">
        {isEditing ? (
          <Input
            type="number"
            value={incrementPrice}
            onChange={(e) => setIncrementPrice(e.target.value)}
            className="w-32 text-right"
            data-testid={`input-increment-price-${tariff.id}`}
          />
        ) : (
          <span className="font-mono text-sm text-foreground">
            +{parseFloat(tariff.incrementPrice).toLocaleString("ru-RU")} ₽
          </span>
        )}
      </td>
      <td className="py-3 px-4 text-right">
        {isEditing ? (
          <div className="flex items-center justify-end gap-2">
            <button
              onClick={handleSave}
              disabled={updateMutation.isPending}
              className="p-1 hover-elevate rounded"
              data-testid={`button-save-${tariff.id}`}
            >
              <Check className="h-4 w-4 text-green-600" />
            </button>
            <button
              onClick={handleCancel}
              disabled={updateMutation.isPending}
              className="p-1 hover-elevate rounded"
              data-testid={`button-cancel-${tariff.id}`}
            >
              <X className="h-4 w-4 text-red-600" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => setIsEditing(true)}
            className="p-1 hover-elevate rounded"
            data-testid={`button-edit-${tariff.id}`}
          >
            <Edit2 className="h-4 w-4 text-muted-foreground" />
          </button>
        )}
      </td>
    </tr>
  );
}

export default function AdminTariffsPage() {
  const { data: tariffs, isLoading: tariffsLoading } = useQuery<Tariff[]>({
    queryKey: ["/api/tariffs"],
  });

  const { data: equipmentTypes } = useQuery<EquipmentType[]>({
    queryKey: ["/api/equipment-types"],
  });

  const getTypeName = (typeId: string | null) => {
    if (!typeId) return "Комплект";
    return equipmentTypes?.find(t => t.id === typeId)?.name || typeId;
  };

  if (tariffsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const groupedTariffs = tariffs?.reduce((acc, tariff) => {
    const typeName = getTypeName(tariff.equipmentTypeId);
    if (!acc[typeName]) {
      acc[typeName] = [];
    }
    acc[typeName].push(tariff);
    return acc;
  }, {} as Record<string, Tariff[]>);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Тарифы</h1>
              <p className="text-muted-foreground mt-1">
                Управление ценами на прокат
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {!groupedTariffs || Object.keys(groupedTariffs).length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <div className="text-center">
                <Settings className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Нет тарифов в системе</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedTariffs).map(([typeName, typeTariffs]) => (
              <Card key={typeName}>
                <CardHeader>
                  <CardTitle>{typeName}</CardTitle>
                  <CardDescription>
                    Тарифов: {typeTariffs.length}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                            Тип дня
                          </th>
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                            Категория
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-semibold text-foreground">
                            Базовая цена
                          </th>
                          <th className="text-center py-3 px-4 text-sm font-semibold text-foreground">
                            Часов
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-semibold text-foreground">
                            +{typeTariffs[0]?.incrementMinutes || 30} мин
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-semibold text-foreground">
                            Действия
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {typeTariffs.map((tariff) => (
                          <TariffRow key={tariff.id} tariff={tariff} />
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
