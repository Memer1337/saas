import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { ArrowLeft, Plus, Trash2, Loader2, UserPlus, Barcode } from "lucide-react";
import { Client, EquipmentType, Tariff } from "@shared/schema";
import { addHours, addMinutes, differenceInMinutes, startOfHour } from "date-fns";

interface OrderItemInput {
  equipmentTypeId: string;
  category: "ADULT" | "CHILD";
  quantity: number;
  price: number;
  isFree: boolean;
  freeReason?: string;
}

interface PriceCalculation {
  subtotal: number;
  discount: number;
  total: number;
  breakdown: Array<{
    equipmentType: string;
    category: string;
    quantity: number;
    price: number;
    isFree: boolean;
  }>;
}

export default function NewOrderPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const [clientId, setClientId] = useState<string>("");
  const [startTime, setStartTime] = useState(addMinutes(new Date(), 15).toISOString().slice(0, 16));
  const [endTime, setEndTime] = useState(addMinutes(new Date(), 15 + 120).toISOString().slice(0, 16));
  const [items, setItems] = useState<OrderItemInput[]>([]);
  const [discountPercent, setDiscountPercent] = useState(0);
  const [notes, setNotes] = useState("");
  
  // Quick client creation
  const [showNewClientDialog, setShowNewClientDialog] = useState(false);
  const [newClientName, setNewClientName] = useState("");
  const [newClientPhone, setNewClientPhone] = useState("");
  
  // Barcode scanning
  const [barcodeInput, setBarcodeInput] = useState("");

  const { data: clients } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  const { data: equipmentTypes } = useQuery<EquipmentType[]>({
    queryKey: ["/api/equipment-types"],
  });

  const { data: tariffs } = useQuery<Tariff[]>({
    queryKey: ["/api/tariffs"],
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/orders", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Заказ создан",
        description: "Заказ успешно сохранён",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setLocation("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createClientMutation = useMutation({
    mutationFn: async (data: { fullName: string; phone?: string }) => {
      const res = await apiRequest("POST", "/api/clients", data);
      return res.json();
    },
    onSuccess: async (newClient) => {
      toast({
        title: "Клиент создан",
        description: `Клиент ${newClient.fullName} успешно добавлен`,
      });
      await queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      setClientId(newClient.id);
      setShowNewClientDialog(false);
      setNewClientName("");
      setNewClientPhone("");
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const calculatePrice = (): PriceCalculation => {
    if (!tariffs || items.length === 0) {
      return { subtotal: 0, discount: 0, total: 0, breakdown: [] };
    }

    const start = new Date(startTime);
    const end = new Date(endTime);
    const minutes = differenceInMinutes(end, start);
    const dayType = getDayType(start);

    let subtotal = 0;
    const breakdown: PriceCalculation["breakdown"] = [];

    items.forEach((item) => {
      if (item.isFree) {
        breakdown.push({
          equipmentType: item.equipmentTypeId,
          category: item.category,
          quantity: item.quantity,
          price: 0,
          isFree: true,
        });
        return;
      }

      const equipType = equipmentTypes?.find(t => t.id === item.equipmentTypeId);
      const tariff = tariffs.find(
        (t) => t.equipmentTypeId === item.equipmentTypeId &&
          t.category === item.category &&
          t.dayType === dayType
      );

      if (!tariff) return;

      let price = 0;

      if (equipType?.rentalMode === "DAILY_ONLY") {
        // Daily only pricing
        price = parseFloat(tariff.basePrice);
      } else {
        // Hourly pricing
        const baseMinutes = tariff.baseHours * 60;
        price = parseFloat(tariff.basePrice);

        if (minutes > baseMinutes) {
          const extraMinutes = minutes - baseMinutes;
          const increments = Math.ceil(extraMinutes / tariff.incrementMinutes);
          price += increments * parseFloat(tariff.incrementPrice);
        }
      }

      const itemTotal = price * item.quantity;
      subtotal += itemTotal;

      breakdown.push({
        equipmentType: item.equipmentTypeId,
        category: item.category,
        quantity: item.quantity,
        price: itemTotal,
        isFree: false,
      });
    });

    const discount = (subtotal * discountPercent) / 100;
    const total = subtotal - discount;

    return { subtotal, discount, total, breakdown };
  };

  const getDayType = (date: Date): "WEEKDAY" | "WEEKEND" => {
    const day = date.getDay();
    return day === 0 || day === 6 ? "WEEKEND" : "WEEKDAY";
  };

  const addItem = () => {
    setItems([
      ...items,
      {
        equipmentTypeId: "",
        category: "ADULT",
        quantity: 1,
        price: 0,
        isFree: false,
      },
    ]);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const updateItem = (index: number, field: keyof OrderItemInput, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
  };

  const handleBarcodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcodeInput.trim()) return;

    try {
      const res = await fetch(`/api/equipment-items?itemNumber=${encodeURIComponent(barcodeInput.trim())}`);
      if (!res.ok) {
        throw new Error("Оборудование не найдено");
      }
      const equipmentList = await res.json();
      
      if (!equipmentList || equipmentList.length === 0) {
        toast({
          title: "Не найдено",
          description: `Оборудование с номером ${barcodeInput} не найдено`,
          variant: "destructive",
        });
        return;
      }

      const equipment = equipmentList[0];
      
      // Check if this equipment type is already in items
      const existingIndex = items.findIndex(
        item => item.equipmentTypeId === equipment.equipmentTypeId && item.category === "ADULT"
      );

      if (existingIndex >= 0) {
        // Increment quantity
        const newItems = [...items];
        newItems[existingIndex].quantity += 1;
        setItems(newItems);
        toast({
          title: "Добавлено",
          description: `Количество увеличено`,
        });
      } else {
        // Add new item
        setItems([
          ...items,
          {
            equipmentTypeId: equipment.equipmentTypeId,
            category: "ADULT",
            quantity: 1,
            price: 0,
            isFree: false,
          },
        ]);
        toast({
          title: "Добавлено",
          description: `Оборудование ${barcodeInput} добавлено в заказ`,
        });
      }

      setBarcodeInput("");
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleCreateClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientName.trim()) {
      toast({
        title: "Ошибка",
        description: "Введите имя клиента",
        variant: "destructive",
      });
      return;
    }
    createClientMutation.mutate({
      fullName: newClientName.trim(),
      phone: newClientPhone.trim() || undefined,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!clientId) {
      toast({
        title: "Ошибка",
        description: "Выберите клиента",
        variant: "destructive",
      });
      return;
    }

    if (!startTime || !endTime) {
      toast({
        title: "Ошибка",
        description: "Укажите время начала и окончания аренды",
        variant: "destructive",
      });
      return;
    }

    if (items.length === 0) {
      toast({
        title: "Ошибка",
        description: "Добавьте хотя бы одну позицию",
        variant: "destructive",
      });
      return;
    }

    const calculation = calculatePrice();

    createOrderMutation.mutate({
      clientId,
      workspaceId: user!.workspaceId,
      locationId: user!.locationId || user!.workspaceId,
      startTime: new Date(startTime).toISOString(),
      endTime: new Date(endTime).toISOString(),
      items: items.map((item) => ({
        equipmentTypeId: item.equipmentTypeId,
        category: item.category,
        quantity: item.quantity,
        price: item.isFree ? "0" : item.price.toString(),
        isFree: item.isFree,
        freeReason: item.freeReason,
      })),
      subtotal: calculation.subtotal.toString(),
      discountPercent,
      discountFixed: "0",
      total: calculation.total.toString(),
      notes,
      createdById: user!.id,
    });
  };

  const calculation = calculatePrice();

  return (
    <div className="min-h-screen bg-background">
      {/* Dialog for creating new client - must be outside of form */}
      <Dialog open={showNewClientDialog} onOpenChange={setShowNewClientDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Создать нового клиента</DialogTitle>
            <DialogDescription>
              Введите данные клиента для быстрого добавления
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateClient} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="newClientName">Имя и фамилия *</Label>
              <Input
                id="newClientName"
                value={newClientName}
                onChange={(e) => setNewClientName(e.target.value)}
                placeholder="Иван Иванов"
                data-testid="input-new-client-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newClientPhone">Телефон</Label>
              <Input
                id="newClientPhone"
                value={newClientPhone}
                onChange={(e) => setNewClientPhone(e.target.value)}
                placeholder="+7 (999) 123-45-67"
                data-testid="input-new-client-phone"
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowNewClientDialog(false)}
              >
                Отмена
              </Button>
              <Button 
                type="submit"
                disabled={createClientMutation.isPending}
                data-testid="button-create-client-submit"
              >
                {createClientMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Создать
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Новый заказ</h1>
              <p className="text-muted-foreground mt-1">
                Создайте заказ и рассчитайте стоимость
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <form onSubmit={handleSubmit} className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Order Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Информация о заказе</CardTitle>
                <CardDescription>Заполните основные данные</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="client">Клиент *</Label>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => setShowNewClientDialog(true)}
                      data-testid="button-new-client"
                    >
                      <UserPlus className="h-4 w-4 mr-2" />
                      Новый клиент
                    </Button>
                  </div>
                  <Select value={clientId} onValueChange={setClientId}>
                    <SelectTrigger id="client" data-testid="select-client">
                      <SelectValue placeholder="Выберите клиента" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients?.map((client) => (
                        <SelectItem key={client.id} value={client.id}>
                          {client.fullName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startTime">Начало аренды *</Label>
                    <Input
                      id="startTime"
                      type="datetime-local"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      data-testid="input-start-time"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endTime">Окончание аренды *</Label>
                    <Input
                      id="endTime"
                      type="datetime-local"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      data-testid="input-end-time"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Комментарий</Label>
                  <Input
                    id="notes"
                    type="text"
                    placeholder="Дополнительная информация"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    data-testid="input-notes"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Позиции заказа</CardTitle>
                    <CardDescription>Добавьте оборудование для аренды</CardDescription>
                  </div>
                  <Button type="button" onClick={addItem} data-testid="button-add-item">
                    <Plus className="mr-2 h-4 w-4" />
                    Добавить
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Barcode Scanner */}
                <div className="p-4 border-2 border-dashed border-border rounded-lg bg-muted/50">
                  <div className="space-y-2">
                    <Label htmlFor="barcode" className="flex items-center gap-2 text-sm font-medium">
                      <Barcode className="h-4 w-4" />
                      Сканировать штрих-код
                    </Label>
                    <div className="flex gap-2">
                      <Input
                        id="barcode"
                        type="text"
                        value={barcodeInput}
                        onChange={(e) => setBarcodeInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleBarcodeSubmit(e as any);
                          }
                        }}
                        placeholder="Отсканируйте или введите номер оборудования"
                        data-testid="input-barcode"
                        className="flex-1"
                      />
                      <Button 
                        type="button"
                        onClick={handleBarcodeSubmit} 
                        disabled={!barcodeInput.trim()}
                        data-testid="button-barcode-submit"
                      >
                        Добавить
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Оборудование автоматически добавится в заказ
                    </p>
                  </div>
                </div>

                <Separator />

                {items.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    Нажмите "Добавить" чтобы добавить позиции
                  </div>
                ) : (
                  items.map((item, index) => (
                    <div
                      key={index}
                      className="p-4 border border-border rounded-lg space-y-4"
                      data-testid={`item-${index}`}
                    >
                      <div className="grid grid-cols-[1fr_auto] gap-4">
                        <div className="grid grid-cols-3 gap-4">
                          <div className="space-y-2">
                            <Label>Оборудование</Label>
                            <Select
                              value={item.equipmentTypeId}
                              onValueChange={(value) =>
                                updateItem(index, "equipmentTypeId", value)
                              }
                            >
                              <SelectTrigger data-testid={`select-equipment-${index}`}>
                                <SelectValue placeholder="Выбрать" />
                              </SelectTrigger>
                              <SelectContent>
                                {equipmentTypes?.map((type) => (
                                  <SelectItem key={type.id} value={type.id}>
                                    {type.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label>Категория</Label>
                            <Select
                              value={item.category}
                              onValueChange={(value) =>
                                updateItem(index, "category", value as "ADULT" | "CHILD")
                              }
                            >
                              <SelectTrigger data-testid={`select-category-${index}`}>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="ADULT">Взрослый</SelectItem>
                                <SelectItem value="CHILD">Детский</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label>Количество</Label>
                            <Input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) =>
                                updateItem(index, "quantity", parseInt(e.target.value))
                              }
                              data-testid={`input-quantity-${index}`}
                            />
                          </div>
                        </div>

                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(index)}
                          data-testid={`button-remove-${index}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      {item.isFree && (
                        <Badge variant="secondary">Бесплатно</Badge>
                      )}
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Price Calculation */}
          <div className="lg:col-span-1">
            <div className="sticky top-6">
              <Card>
                <CardHeader>
                  <CardTitle>Расчёт стоимости</CardTitle>
                  <CardDescription>Итоговая сумма заказа</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    {calculation.breakdown.map((item, index) => (
                      <div
                        key={index}
                        className="flex justify-between text-sm"
                        data-testid={`breakdown-${index}`}
                      >
                        <span className="text-muted-foreground">
                          {item.equipmentType} ({item.category === "ADULT" ? "Взр" : "Дет"}) × {item.quantity}
                        </span>
                        <span className="font-mono font-medium">
                          {item.isFree ? (
                            <Badge variant="secondary" className="text-xs">Бесплатно</Badge>
                          ) : (
                            `${item.price.toLocaleString("ru-RU")} ₽`
                          )}
                        </span>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Подытог</span>
                    <span className="font-mono font-medium">
                      {calculation.subtotal.toLocaleString("ru-RU")} ₽
                    </span>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="discount">Скидка (%)</Label>
                    <Input
                      id="discount"
                      type="number"
                      min="0"
                      max="100"
                      value={discountPercent}
                      onChange={(e) => setDiscountPercent(parseInt(e.target.value) || 0)}
                      data-testid="input-discount"
                    />
                  </div>

                  {discountPercent > 0 && (
                    <div className="flex justify-between text-sm text-green-600 dark:text-green-400">
                      <span>Скидка {discountPercent}%</span>
                      <span className="font-mono font-medium">
                        -{calculation.discount.toLocaleString("ru-RU")} ₽
                      </span>
                    </div>
                  )}

                  <Separator />

                  <div className="flex justify-between">
                    <span className="text-lg font-semibold text-foreground">Итого</span>
                    <span className="text-2xl font-bold font-mono text-foreground">
                      {calculation.total.toLocaleString("ru-RU")} ₽
                    </span>
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={createOrderMutation.isPending}
                    data-testid="button-create-order"
                  >
                    {createOrderMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    Создать заказ
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
