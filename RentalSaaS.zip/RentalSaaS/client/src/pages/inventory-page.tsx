import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Package, Loader2, Plus, Pencil, Trash2, Check, X, Barcode as BarcodeIcon } from "lucide-react";
import { EquipmentItem, EquipmentType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { nanoid } from "nanoid";
import Barcode from "react-barcode";

export default function InventoryPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState<Partial<EquipmentItem>>({});
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newItem, setNewItem] = useState({
    equipmentTypeId: "",
    itemNumber: "",
    barcode: "",
    status: "AVAILABLE",
    notes: "",
  });
  const [barcodeSearchValue, setBarcodeSearchValue] = useState("");

  const { data: items, isLoading: itemsLoading } = useQuery<EquipmentItem[]>({
    queryKey: ["/api/equipment-items"],
  });

  const { data: types } = useQuery<EquipmentType[]>({
    queryKey: ["/api/equipment-types"],
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<EquipmentItem> }) => {
      const res = await apiRequest("PATCH", `/api/equipment-items/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Сохранено", description: "Оборудование обновлено" });
      queryClient.invalidateQueries({ queryKey: ["/api/equipment-items"] });
      setEditingId(null);
      setEditData({});
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/equipment-items/${id}`);
    },
    onSuccess: () => {
      toast({ title: "Удалено", description: "Оборудование удалено" });
      queryClient.invalidateQueries({ queryKey: ["/api/equipment-items"] });
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const addMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/equipment-items", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Добавлено", description: "Оборудование добавлено" });
      queryClient.invalidateQueries({ queryKey: ["/api/equipment-items"] });
      setShowAddDialog(false);
      setNewItem({
        equipmentTypeId: "",
        itemNumber: "",
        barcode: "",
        status: "AVAILABLE",
        notes: "",
      });
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const startEdit = (item: EquipmentItem) => {
    setEditingId(item.id);
    setEditData({
      itemNumber: item.itemNumber,
      status: item.status,
      notes: item.notes || "",
    });
  };

  const saveEdit = (id: string) => {
    updateMutation.mutate({ id, data: editData });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditData({});
  };

  const handleDelete = (id: string) => {
    if (confirm("Вы уверены, что хотите удалить это оборудование?")) {
      deleteMutation.mutate(id);
    }
  };

  const generateBarcode = () => {
    const prefix = "EQ";
    const code = nanoid(10).toUpperCase().replace(/[^A-Z0-9]/g, '');
    return `${prefix}-${code}`;
  };

  const handleAdd = () => {
    if (!newItem.equipmentTypeId || !newItem.itemNumber) {
      toast({ 
        title: "Ошибка", 
        description: "Заполните тип и номер оборудования", 
        variant: "destructive" 
      });
      return;
    }
    
    const barcodeToUse = newItem.barcode || generateBarcode();
    
    addMutation.mutate({
      ...newItem,
      barcode: barcodeToUse,
      workspaceId: user!.workspaceId,
      locationId: user!.locationId || user!.workspaceId,
    });
  };

  const handleOpenAddDialog = () => {
    setNewItem({
      equipmentTypeId: "",
      itemNumber: "",
      barcode: generateBarcode(),
      status: "AVAILABLE",
      notes: "",
    });
    setShowAddDialog(true);
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { label: string; className: string }> = {
      AVAILABLE: { label: "Доступно", className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" },
      RENTED: { label: "В аренде", className: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" },
      SERVICE: { label: "На сервисе", className: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200" },
      LOST: { label: "Утеряно", className: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200" },
    };
    const config = variants[status] || variants.AVAILABLE;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const getTypeName = (typeId: string) => {
    return types?.find(t => t.id === typeId)?.name || typeId;
  };

  if (itemsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const filteredItems = items?.filter(item => {
    if (!barcodeSearchValue) return true;
    return item.barcode?.toLowerCase().includes(barcodeSearchValue.toLowerCase()) ||
           item.itemNumber.toLowerCase().includes(barcodeSearchValue.toLowerCase());
  });

  const groupedByType = filteredItems?.reduce((acc, item) => {
    const typeName = getTypeName(item.equipmentTypeId);
    if (!acc[typeName]) {
      acc[typeName] = [];
    }
    acc[typeName].push(item);
    return acc;
  }, {} as Record<string, EquipmentItem[]>);

  return (
    <div className="min-h-screen bg-background">
      {/* Add Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Добавить оборудование</DialogTitle>
            <DialogDescription>
              Добавьте новую единицу оборудования в инвентарь
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="type">Тип оборудования *</Label>
              {/* Hidden native select for testing */}
              <select
                data-testid="select-new-type-native"
                value={newItem.equipmentTypeId}
                onChange={(e) => setNewItem({ ...newItem, equipmentTypeId: e.target.value })}
                className="sr-only"
                aria-hidden="true"
                tabIndex={-1}
              >
                <option value="">Выберите тип</option>
                {types?.map((type) => (
                  <option key={type.id} value={type.id}>
                    {type.name}
                  </option>
                ))}
              </select>
              <Select value={newItem.equipmentTypeId} onValueChange={(v) => setNewItem({ ...newItem, equipmentTypeId: v })}>
                <SelectTrigger id="type" data-testid="select-new-type">
                  <SelectValue placeholder="Выберите тип" />
                </SelectTrigger>
                <SelectContent>
                  {types?.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="itemNumber">Номер *</Label>
              <Input
                id="itemNumber"
                value={newItem.itemNumber}
                onChange={(e) => setNewItem({ ...newItem, itemNumber: e.target.value })}
                placeholder="Например: ЛЫЖ-001"
                data-testid="input-new-item-number"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="barcode">Штрихкод</Label>
              <div className="flex gap-2">
                <Input
                  id="barcode"
                  value={newItem.barcode}
                  onChange={(e) => setNewItem({ ...newItem, barcode: e.target.value })}
                  placeholder="Автогенерируется"
                  className="font-mono"
                  data-testid="input-new-barcode"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setNewItem({ ...newItem, barcode: generateBarcode() })}
                  data-testid="button-regenerate-barcode"
                >
                  <BarcodeIcon className="h-4 w-4" />
                </Button>
              </div>
              {newItem.barcode && (
                <div className="flex justify-center p-2 bg-white rounded border">
                  <Barcode value={newItem.barcode} height={40} fontSize={12} />
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Статус</Label>
              <Select value={newItem.status} onValueChange={(v) => setNewItem({ ...newItem, status: v })}>
                <SelectTrigger id="status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AVAILABLE">Доступно</SelectItem>
                  <SelectItem value="RENTED">В аренде</SelectItem>
                  <SelectItem value="SERVICE">На сервисе</SelectItem>
                  <SelectItem value="LOST">Утеряно</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Заметки</Label>
              <Input
                id="notes"
                value={newItem.notes}
                onChange={(e) => setNewItem({ ...newItem, notes: e.target.value })}
                placeholder="Дополнительная информация"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
              Отмена
            </Button>
            <Button 
              onClick={handleAdd} 
              disabled={addMutation.isPending}
              data-testid="button-add-submit"
            >
              {addMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Добавить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Инвентарь</h1>
              <p className="text-muted-foreground mt-1">
                Управление оборудованием
              </p>
            </div>
            <div className="flex gap-2">
              <Input
                value={barcodeSearchValue}
                onChange={(e) => setBarcodeSearchValue(e.target.value)}
                placeholder="Поиск по штрихкоду..."
                className="w-64"
                data-testid="input-barcode-search"
              />
              <Button onClick={handleOpenAddDialog} data-testid="button-add-equipment">
                <Plus className="mr-2 h-4 w-4" />
                Добавить
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {!groupedByType || Object.keys(groupedByType).length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <div className="text-center">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Нет оборудования в базе</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedByType).map(([typeName, typeItems]) => (
              <Card key={typeName}>
                <CardHeader>
                  <CardTitle>{typeName}</CardTitle>
                  <CardDescription>
                    Всего единиц: {typeItems.length}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                            Номер
                          </th>
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                            Штрихкод
                          </th>
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                            Статус
                          </th>
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">
                            Заметки
                          </th>
                          <th className="text-right py-3 px-4 text-sm font-semibold text-foreground">
                            Действия
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {typeItems.map((item) => (
                          <tr
                            key={item.id}
                            className="border-b border-border hover-elevate"
                            data-testid={`row-item-${item.id}`}
                          >
                            {editingId === item.id ? (
                              <>
                                <td className="py-3 px-4">
                                  <Input
                                    value={editData.itemNumber || ""}
                                    onChange={(e) => setEditData({ ...editData, itemNumber: e.target.value })}
                                    className="font-mono text-sm"
                                    data-testid={`input-edit-number-${item.id}`}
                                  />
                                </td>
                                <td className="py-3 px-4">
                                  <span className="font-mono text-xs text-muted-foreground">
                                    {item.barcode || "—"}
                                  </span>
                                </td>
                                <td className="py-3 px-4">
                                  <Select
                                    value={editData.status || item.status}
                                    onValueChange={(v) => setEditData({ ...editData, status: v as any })}
                                  >
                                    <SelectTrigger data-testid={`select-edit-status-${item.id}`}>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="AVAILABLE">Доступно</SelectItem>
                                      <SelectItem value="RENTED">В аренде</SelectItem>
                                      <SelectItem value="SERVICE">На сервисе</SelectItem>
                                      <SelectItem value="LOST">Утеряно</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </td>
                                <td className="py-3 px-4">
                                  <Input
                                    value={editData.notes || ""}
                                    onChange={(e) => setEditData({ ...editData, notes: e.target.value })}
                                    className="text-sm"
                                    placeholder="Заметки"
                                  />
                                </td>
                                <td className="py-3 px-4">
                                  <div className="flex items-center justify-end gap-2">
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      onClick={() => saveEdit(item.id)}
                                      disabled={updateMutation.isPending}
                                      data-testid={`button-save-${item.id}`}
                                    >
                                      <Check className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      onClick={cancelEdit}
                                      data-testid={`button-cancel-${item.id}`}
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </td>
                              </>
                            ) : (
                              <>
                                <td className="py-3 px-4">
                                  <span className="font-mono text-sm font-medium text-foreground">
                                    {item.itemNumber}
                                  </span>
                                </td>
                                <td className="py-3 px-4">
                                  {item.barcode ? (
                                    <span className="font-mono text-xs text-muted-foreground">
                                      {item.barcode}
                                    </span>
                                  ) : (
                                    <span className="text-xs text-muted-foreground">—</span>
                                  )}
                                </td>
                                <td className="py-3 px-4">
                                  {getStatusBadge(item.status)}
                                </td>
                                <td className="py-3 px-4 text-sm text-muted-foreground">
                                  {item.notes || "-"}
                                </td>
                                <td className="py-3 px-4">
                                  <div className="flex items-center justify-end gap-2">
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      onClick={() => startEdit(item)}
                                      data-testid={`button-edit-${item.id}`}
                                    >
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      onClick={() => handleDelete(item.id)}
                                      disabled={deleteMutation.isPending}
                                      data-testid={`button-delete-${item.id}`}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </td>
                              </>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
