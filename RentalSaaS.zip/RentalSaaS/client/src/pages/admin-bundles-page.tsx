import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Package, Plus, Trash2, Loader2, Edit } from "lucide-react";
import { BundleDefinition, BundleComponent, EquipmentType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Checkbox } from "@/components/ui/checkbox";

interface BundleWithComponents extends BundleDefinition {
  components?: BundleComponent[];
}

export default function AdminBundlesPage() {
  const { toast } = useToast();
  const [showDialog, setShowDialog] = useState(false);
  const [editingBundle, setEditingBundle] = useState<BundleDefinition | null>(null);
  const [bundleName, setBundleName] = useState("");
  const [bundleDesc, setBundleDesc] = useState("");
  const [selectedComponents, setSelectedComponents] = useState<{ 
    equipmentTypeId: string; 
    quantity: number;
    isOptional: boolean;
  }[]>([]);

  const { data: bundles, isLoading } = useQuery<BundleDefinition[]>({
    queryKey: ["/api/bundles"],
  });

  const { data: equipmentTypes } = useQuery<EquipmentType[]>({
    queryKey: ["/api/equipment-types"],
  });

  const createBundleMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/bundles", {
        name: data.name,
        description: data.description,
      });
      return res.json();
    },
    onSuccess: async (newBundle) => {
      // Add components
      for (const comp of selectedComponents) {
        await apiRequest("POST", `/api/bundles/${newBundle.id}/components`, comp);
      }
      toast({ title: "Создано", description: "Комплект успешно создан" });
      queryClient.invalidateQueries({ queryKey: ["/api/bundles"] });
      resetForm();
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const updateBundleMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/bundles/${data.id}`, {
        name: data.name,
        description: data.description,
      });
      return res.json();
    },
    onSuccess: async (updatedBundle) => {
      // Delete old components
      const existingComps = await fetch(`/api/bundles/${updatedBundle.id}/components`).then(r => r.json());
      for (const comp of existingComps) {
        await apiRequest("DELETE", `/api/bundle-components/${comp.id}`);
      }
      // Add new components
      for (const comp of selectedComponents) {
        await apiRequest("POST", `/api/bundles/${updatedBundle.id}/components`, comp);
      }
      toast({ title: "Сохранено", description: "Комплект обновлен" });
      queryClient.invalidateQueries({ queryKey: ["/api/bundles"] });
      resetForm();
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const deleteBundleMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/bundles/${id}`);
    },
    onSuccess: () => {
      toast({ title: "Удалено", description: "Комплект удален" });
      queryClient.invalidateQueries({ queryKey: ["/api/bundles"] });
    },
    onError: (error: Error) => {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setShowDialog(false);
    setEditingBundle(null);
    setBundleName("");
    setBundleDesc("");
    setSelectedComponents([]);
  };

  const openCreateDialog = () => {
    resetForm();
    setShowDialog(true);
  };

  const openEditDialog = async (bundle: BundleDefinition) => {
    setEditingBundle(bundle);
    setBundleName(bundle.name);
    setBundleDesc(bundle.description || "");
    
    // Load existing components
    const components = await fetch(`/api/bundles/${bundle.id}/components`).then(r => r.json());
    setSelectedComponents(components.map((c: BundleComponent) => ({
      equipmentTypeId: c.equipmentTypeId,
      quantity: c.quantity,
      isOptional: c.isOptional,
    })));
    setShowDialog(true);
  };

  const handleSave = () => {
    if (!bundleName || selectedComponents.length === 0) {
      toast({
        title: "Ошибка",
        description: "Укажите название и хотя бы один компонент",
        variant: "destructive",
      });
      return;
    }

    if (editingBundle) {
      updateBundleMutation.mutate({
        id: editingBundle.id,
        name: bundleName,
        description: bundleDesc,
      });
    } else {
      createBundleMutation.mutate({
        name: bundleName,
        description: bundleDesc,
      });
    }
  };

  const handleDelete = (id: string) => {
    if (confirm("Вы уверены, что хотите удалить этот комплект?")) {
      deleteBundleMutation.mutate(id);
    }
  };

  const addComponent = () => {
    if (!equipmentTypes || equipmentTypes.length === 0) return;
    setSelectedComponents([
      ...selectedComponents,
      {
        equipmentTypeId: equipmentTypes[0].id,
        quantity: 1,
        isOptional: false,
      },
    ]);
  };

  const removeComponent = (index: number) => {
    setSelectedComponents(selectedComponents.filter((_, i) => i !== index));
  };

  const updateComponent = (index: number, field: string, value: any) => {
    const newComponents = [...selectedComponents];
    newComponents[index] = { ...newComponents[index], [field]: value };
    setSelectedComponents(newComponents);
  };

  const getTypeName = (typeId: string) => {
    return equipmentTypes?.find(t => t.id === typeId)?.name || typeId;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Dialog for creating/editing bundle */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingBundle ? "Редактировать комплект" : "Создать комплект"}
            </DialogTitle>
            <DialogDescription>
              Настройте состав комплекта оборудования
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bundleName">Название комплекта *</Label>
              <Input
                id="bundleName"
                value={bundleName}
                onChange={(e) => setBundleName(e.target.value)}
                placeholder="Например: Комплект для лыж"
                data-testid="input-bundle-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bundleDesc">Описание</Label>
              <Input
                id="bundleDesc"
                value={bundleDesc}
                onChange={(e) => setBundleDesc(e.target.value)}
                placeholder="Дополнительная информация"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Компоненты комплекта *</Label>
                <Button type="button" variant="outline" size="sm" onClick={addComponent}>
                  <Plus className="h-4 w-4 mr-2" />
                  Добавить
                </Button>
              </div>
              
              {selectedComponents.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  Нажмите "Добавить" чтобы добавить компоненты
                </p>
              ) : (
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {selectedComponents.map((comp, index) => (
                    <div key={index} className="flex items-center gap-2 p-3 border rounded-lg">
                      <div className="flex-1">
                        <Select
                          value={comp.equipmentTypeId}
                          onValueChange={(v) => updateComponent(index, "equipmentTypeId", v)}
                        >
                          <SelectTrigger data-testid={`select-component-type-${index}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {equipmentTypes?.map((type) => (
                              <SelectItem key={type.id} value={type.id}>
                                {type.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="w-20">
                        <Input
                          type="number"
                          min="1"
                          value={comp.quantity}
                          onChange={(e) => updateComponent(index, "quantity", parseInt(e.target.value))}
                          placeholder="Кол-во"
                          data-testid={`input-component-quantity-${index}`}
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={comp.isOptional}
                          onCheckedChange={(checked) => updateComponent(index, "isOptional", checked)}
                          data-testid={`checkbox-optional-${index}`}
                        />
                        <Label className="text-xs">Опц.</Label>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeComponent(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={resetForm}>
              Отмена
            </Button>
            <Button
              onClick={handleSave}
              disabled={createBundleMutation.isPending || updateBundleMutation.isPending}
              data-testid="button-save-bundle"
            >
              {(createBundleMutation.isPending || updateBundleMutation.isPending) && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Настройка комплектов</h1>
              <p className="text-muted-foreground mt-1">
                Определите, что входит в каждый комплект оборудования
              </p>
            </div>
            <Button onClick={openCreateDialog} data-testid="button-create-bundle">
              <Plus className="mr-2 h-4 w-4" />
              Создать комплект
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {!bundles || bundles.length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <div className="text-center">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground mb-4">Нет настроенных комплектов</p>
                <Button onClick={openCreateDialog}>
                  <Plus className="mr-2 h-4 w-4" />
                  Создать первый комплект
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {bundles.map((bundle) => (
              <BundleCard
                key={bundle.id}
                bundle={bundle}
                getTypeName={getTypeName}
                onEdit={() => openEditDialog(bundle)}
                onDelete={() => handleDelete(bundle.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

interface BundleCardProps {
  bundle: BundleDefinition;
  getTypeName: (typeId: string) => string;
  onEdit: () => void;
  onDelete: () => void;
}

function BundleCard({ bundle, getTypeName, onEdit, onDelete }: BundleCardProps) {
  const { data: components } = useQuery<BundleComponent[]>({
    queryKey: [`/api/bundles/${bundle.id}/components`],
    queryFn: async () => {
      const res = await fetch(`/api/bundles/${bundle.id}/components`);
      return res.json();
    },
  });

  return (
    <Card data-testid={`card-bundle-${bundle.id}`}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle>{bundle.name}</CardTitle>
            {bundle.description && (
              <CardDescription className="mt-1">{bundle.description}</CardDescription>
            )}
          </div>
          <div className="flex gap-2">
            <Button
              size="icon"
              variant="ghost"
              onClick={onEdit}
              data-testid={`button-edit-bundle-${bundle.id}`}
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={onDelete}
              data-testid={`button-delete-bundle-${bundle.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <p className="text-sm font-medium text-foreground">Состав:</p>
          {!components || components.length === 0 ? (
            <p className="text-sm text-muted-foreground">Нет компонентов</p>
          ) : (
            <div className="space-y-1">
              {components.map((comp) => (
                <div key={comp.id} className="flex items-center gap-2 text-sm">
                  <span className="text-foreground">
                    {getTypeName(comp.equipmentTypeId)} × {comp.quantity}
                  </span>
                  {comp.isOptional && (
                    <Badge variant="outline" className="text-xs">
                      опционально
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
